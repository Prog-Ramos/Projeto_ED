var NAVTREEINDEX0 =
{
"_jogador_8h_source.html":[1,0,0],
"_menu_8h_source.html":[1,0,1],
"_monstros_8h_source.html":[1,0,2],
"annotated.html":[0,0],
"classes.html":[0,1],
"files.html":[1,0],
"index.html":[],
"pages.html":[],
"struct_banco_monstros.html":[0,0,0],
"struct_jogador.html":[0,0,1],
"struct_monstros.html":[0,0,2]
};
