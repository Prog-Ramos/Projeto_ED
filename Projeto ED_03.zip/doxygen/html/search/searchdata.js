var indexSectionsWithContent =
{
  0: "bjm",
  1: "bjm"
};

var indexSectionNames =
{
  0: "all",
  1: "classes"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes"
};

