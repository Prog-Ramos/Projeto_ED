var annotated_dup =
[
    [ "BancoMonstros", "struct_banco_monstros.html", null ],
    [ "Jogador", "struct_jogador.html", null ],
    [ "Monstros", "struct_monstros.html", null ]
];