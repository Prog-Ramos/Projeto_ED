#ifndef MENU_H
#define MENU_H

#include "Monstros.h"
#include "Jogador.h"


void ExibirMenuPrincipal(Jogador *Player, BancoMonstros *NovoBancoMonstros);

void MenuExplorar(Jogador *Player, BancoMonstros *NovoBancoMonstros);
void MenuStatus(Jogador *Player);
void MenuTreinar(Jogador *Player);
void EncontraMonstro(Jogador *Player, BancoMonstros *NovoBancoMonstros);
void Cidade(Jogador *Player);
void Batalha(Jogador *Player, Monstros *MonstroBatalha);

//Funções adicionadas
void VerificarFome(Jogador *Player);
void AbrirInventario(Jogador *Player);
void Loja(Jogador *Player);
void Acampar(Jogador *Player);

#endif


