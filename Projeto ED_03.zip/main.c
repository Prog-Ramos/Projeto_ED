#include <stdio.h>
#include <math.h>
#include <time.h> //para usar o srand
#include <locale.h>
#include <stdlib.h>

#include "Monstros.h"
#include "Jogador.h"
#include "Menu.h"

int main()
{
    srand(time(NULL)); //time Null: retorna horario de computador em segundos contado a partide de 1 de janeiro de 1970. e srand define a semente que o algoritmo usa de aleatoriedade

    setlocale(LC_ALL, "Portuguese"); //configurar o programa para o idioma portugues

    printf("================ BEM-VINDO AO RPG ================\n\n");

    Jogador Player = CriarJogador(); //jogador � uma struct.

    BancoMonstros NovoBancoMonstros;

    InicializarMonstros(&NovoBancoMonstros);

    ExibirMenuPrincipal(&Player,&NovoBancoMonstros);

    return 0;
}
