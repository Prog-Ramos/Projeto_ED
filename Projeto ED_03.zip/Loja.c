#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <string.h>
#include "Menu.h"

void Loja(Jogador *Player)
{
    int opcao;
    do {
        system("cls");
        printf("==================================================\n");
        printf("                 LOJA DA CIDADE                   \n");
        printf("==================================================\n");
        printf(" Suas Moedas: %i \n", Player->Moedas);
        printf(" Seus Itens  -> Pocoes: %i | Racoes: %i\n", Player->PocaoHp, Player->Racao);
        printf("--------------------------------------------------\n");
        printf(" 1 - COMPRAR: Pocao de HP   [-15 Moedas]\n");
        printf(" 2 - COMPRAR: Racao         [-8 Moedas]\n");
        printf(" 3 - VENDER:  Pocao de HP   [+7 Moedas]\n");
        printf(" 4 - VENDER:  Racao         [+4 Moedas]\n");
        printf(" 5 - Sair da Loja\n");
        printf("==================================================\n");
        printf("Escolha uma opcao: ");
        scanf("%i", &opcao);

        switch(opcao) {
            case 1:
                if (Player->Moedas >= 15) {
                    Player->Moedas -= 15;
                    Player->PocaoHp++;
                    printf("\n> Compra realizada: +1 Pocao de HP!\n");
                } else {
                    printf("\n> Moedas insuficientes!\n");
                }
                getch();
                break;
            case 2:
                if (Player->Moedas >= 8) {
                    Player->Moedas -= 8;
                    Player->Racao++;
                    printf("\n> Compra realizada: +1 Racao!\n");
                } else {
                    printf("\n> Moedas insuficientes!\n");
                }
                getch();
                break;
            case 3:
                if (Player->PocaoHp > 0) {
                    Player->PocaoHp--;
                    Player->Moedas += 7;
                    printf("\n> Venda realizada: +7 Moedas!\n");
                } else {
                    printf("\n> Voce nao possui o item para vender!\n");
                }
                getch();
                break;
            case 4:
                if (Player->Racao > 0) {
                    Player->Racao--;
                    Player->Moedas += 4;
                    printf("\n> Venda realizada: +4 Moedas!\n");
                } else {
                    printf("\n> Voce nao possui o item para vender!\n");
                }
                getch();
                break;
        }
    } while (opcao != 5);
}
