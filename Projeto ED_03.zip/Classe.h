#ifndef Classe_h
#define Classe_h

typedef struct {
    char NomeClasse[50];
    short int Atk;
    short int Def;
    short int HpMax;
} Classe;

#endif
