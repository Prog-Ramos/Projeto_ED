#include <stdio.h>
#include <string.h>
#include <string.h>

#include "Monstros.h"

void InicializarMonstros(BancoMonstros *Banco)
{
    //MONSTROS NIVEL 1
    strcpy(Banco->lista[0].Nome, "Manticora");
    Banco->lista[0].Level = 1;
    Banco->lista[0].HpMax = 30;
    Banco->lista[0].Hp = 30;
    Banco->lista[0].Atk = 16;
    Banco->lista[0].Def = 1;
    Banco->lista[0].Xp = 15;
    Banco->lista[0].Moedas = 10;

    strcpy(Banco->lista[1].Nome, "Quimera");
    Banco->lista[1].Level = 1;
    Banco->lista[1].HpMax = 20;
    Banco->lista[1].Hp = 20;
    Banco->lista[1].Atk = 3;
    Banco->lista[1].Def = 3;
    Banco->lista[1].Xp = 15;
    Banco->lista[1].Moedas = 5;

    strcpy(Banco->lista[2].Nome, "Esfinge");
    Banco->lista[2].Level = 2;
    Banco->lista[2].HpMax = 20;
    Banco->lista[2].Hp = 20;
    Banco->lista[2].Atk = 3;
    Banco->lista[2].Def = 3;
    Banco->lista[2].Xp = 15;
    Banco->lista[2].Moedas = 5;

    strcpy(Banco->lista[3].Nome, "Kraken");
    Banco->lista[3].Level = 2;
    Banco->lista[3].HpMax = 40;
    Banco->lista[3].Hp = 40;
    Banco->lista[3].Atk = 20;
    Banco->lista[3].Def = 6;
    Banco->lista[3].Xp = 70;
    Banco->lista[3].Moedas = 12;

    strcpy(Banco->lista[4].Nome, "Medusa");
    Banco->lista[4].Level = 2;
    Banco->lista[4].HpMax = 25;
    Banco->lista[4].Hp = 25;
    Banco->lista[4].Atk = 15;
    Banco->lista[4].Def = 3;
    Banco->lista[4].Xp = 50;
    Banco->lista[4].Moedas = 9;

    strcpy(Banco->lista[5].Nome, "Dragao");
    Banco->lista[5].Level = 3;
    Banco->lista[5].HpMax = 50;
    Banco->lista[5].Hp = 50;
    Banco->lista[5].Atk = 30;
    Banco->lista[5].Def = 20;
    Banco->lista[5].Xp = 60;
    Banco->lista[5].Moedas = 20;

    strcpy(Banco->lista[6].Nome, "Hipogrifo");
    Banco->lista[6].Level = 1;
    Banco->lista[6].HpMax = 15;
    Banco->lista[6].Hp = 15;
    Banco->lista[6].Atk = 8;
    Banco->lista[6].Def = 16;
    Banco->lista[6].Xp = 10;
    Banco->lista[6].Moedas = 5;

}
