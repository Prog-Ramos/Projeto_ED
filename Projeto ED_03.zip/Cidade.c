#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>

#include "Menu.h"

void Cidade(Jogador *Player)
{

    int opcao;
    if(Player->Energia>=10)
    {
        do {

            system("cls");
            VerificarFome(Player);// Garante que a checagem de fome aconteça no loop da cidade
            printf("======================================================================================================\n");
            printf("   HP = %i/%i  ||  LEVEL = %i  ||  XP = %i/%i  ||  FOME = %i%%  ||  ENERGIA = %i%%  ||  MOEDAS = %i\n", Player->Hp,Player->HpMax,Player->Level, Player->Xp, Player->XpMax,Player->Fome,Player->Energia,Player->Moedas);
            printf("======================================================================================================\n");
            printf("Caminhando");
            sleep(1);
            printf(".");
            sleep(1);
            printf(".");
            sleep(1);
            printf(".");
            sleep(1);
            printf("\n[SISTEMA]Voce chegou na cidade, porem gastou energia!");
            system("pause");
            Player->Energia-= 10; //Gasto de energia para ir para a cidade
            if(Player->Energia<0)
            {
                Player->Energia=0;
            }
            system("cls");
            printf("======================================================================================================\n");
            printf("   HP = %i/%i  ||  LEVEL = %i  ||  XP = %i/%i  ||  FOME = %i%%  ||  ENERGIA = %i%%  ||  MOEDAS = %i\n", Player->Hp,Player->HpMax,Player->Level, Player->Xp, Player->XpMax,Player->Fome,Player->Energia,Player->Moedas);
            printf("======================================================================================================\n");
            printf("==================================================\n");
            printf("               BEM-VINDO A CIDADE                 \n");
            printf("==================================================\n");
            printf(" 1 - Descansar na Estalagem (Cura Tudo) [-15 Moedas]\n");
            printf(" 2 - Comer na Taberna (Enche a Fome)    [-10 Moedas]\n");
            printf(" 3 - Visitar o Mercado (Loja de Itens)\n");
            printf(" 4 - Abrir Inventario Pessoal\n");
            printf(" 5 - Sair da Cidade (Voltar ao Menu)\n");
            printf("==================================================\n");
            printf("Escolha uma opcao: ");
            scanf("%i", &opcao);

            switch(opcao)
            {
                case 1:
                    if(Player->Moedas >= 15) {
                        Player->Moedas -= 15;
                        Player->Hp = Player->HpMax;
                        Player->Energia = 100;
                        printf("\n> Voce dormiu confortavelmente. HP e Energia restaurados!\n");
                        printf("\nPressione qualquer tecla para continuar...");
                        getch();
                    } else {
                        printf("\n> Moedas insuficientes para pagar a estalagem!\n");
                        printf("> Deseja montar um acampamento gratuito ao relento? (1-Sim / 2-Nao): ");
                        int esc;
                        scanf("%i", &esc);
                        if(esc == 1) {
                            Acampar(Player);
                        }
                    }
                    break;

                case 2:
                    if(Player->Moedas >= 10) {
                        Player->Moedas -= 10;
                        Player->Fome += 50;
                        if(Player->Fome > 100) Player->Fome = 100;
                        printf("\n> Voce saboreou uma refeicao deliciosa! Fome saciada.\n");
                    } else {
                        printf("\n> Moedas insuficientes para comer na taberna!\n");
                    }
                    printf("\nPressione qualquer tecla para continuar...");
                    getch();
                    break;

                case 3:
                    Loja(Player);
                    break;

                case 4:
                    AbrirInventario(Player);
                    break;

                case 5:
                    printf("\n> Retornando ao menu principal...\n");
                    printf("\nPressione qualquer tecla para continuar...");
                    getch();
                    break;

                default:
                    printf("\n> Opcao invalida!\n");
                    printf("\nPressione qualquer tecla para continuar...");
                    getch();
                    break;
            }

        } while(opcao != 5);
    }
    else
    {
        printf("\nVoce esta sem energia para ir ate a cidade ! Faça um acampamento para se recuperar !\n");
        system("pause");
    }
}


