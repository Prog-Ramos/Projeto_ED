#include <stdio.h>
#include "Menu.h"
#include <stdlib.h>

void MenuStatus(Jogador *Player)
{
    system("cls");
    printf("==================================================\n");
    printf("                FICHA DO PERSONAGEM               \n");
    printf("==================================================\n");
    printf("Nome: %s\n", Player->Nome);
    printf("Classe: %s\n", Player->Classe);
    printf("Level: %d | XP: %d\n", Player->Level, Player->Xp);
    printf("HP: %d/%d\n", Player->Hp, Player->HpMax);
    printf("Ataque: %d | Defesa: %d\n", Player->Atk, Player->Def);
    printf("Energia: %d%% | Fome: %d%%\n", Player->Energia, Player->Fome);
    printf("Moedas: %d GP\n", Player->Moedas);
    printf("Pocao: %d GP\n", Player->PocaoHp);
    printf("Racao: %d GP\n", Player->Racao);
    printf("==================================================\n");
}
