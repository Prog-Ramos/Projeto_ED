#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <string.h>
#include "Menu.h"

void Acampar(Jogador *Player)
{
    system("cls");
    printf("==================================================\n");
    printf("             ACAMPAMENTO IMPROVISADO              \n");
    printf("==================================================\n");
    printf("> Preparando uma fogueira improvisada na selva...\n");
    printf("> Voce pega no sono tentando descansar...\n\n");
    printf("Pressione [ENTER] para passar a noite...");

    int tecla;
    do { tecla = getch(); } while (tecla != 13);

    // Chance de Emboscada (35% de chance de ser atacado enquanto dorme)
    int chanceEmboscada = rand() % 100;
    if (chanceEmboscada < 35) {
        printf("\n[!] UM MONSTRO TE EMBOSCOU ENQUANTO VOCE DORMIA! [!]\n");
        printf("Pressione [ENTER] para defender-se!");
        do { tecla = getch(); } while (tecla != 13);

        // Criando um monstro de emboscada temporário
        Monstros Ladrao;
        strcpy(Ladrao.Nome, "Saqueador Noturno");
        Ladrao.Hp = 30;
        Ladrao.Atk = 3;
        Ladrao.Def = 1;
        Ladrao.Moedas = 12;
        Ladrao.Xp = 15;

        // Inicia o combate usando a sua função Batalha já existente
        Batalha(Player, &Ladrao);

        printf("\n> Apos repelir o perigo, voce tenta cochilar o resto da noite...\n");
    }

    // Efeitos finais do acampamento
    Player->Hp += (int)(Player->HpMax * 0.25); // Recupera só 25% de HP
    if (Player->Hp > Player->HpMax) Player->Hp = Player->HpMax;

    Player->Energia += 35; // Recupera 35% de energia
    if (Player->Energia > 100) Player->Energia = 100;

    Player->Fome -= 25; // Sente muita fome ao acordar ao relento

    printf("\n==================================================\n");
    printf("[+] HP Parcialmente Restaurado.\n");
    printf("[+] Energia Parcialmente Restaurada.\n");
    printf("[-] Fome aumentada significativamente!\n");
    printf("==================================================\n");

    // Verifica se a perda de fome zerou o atributo e causou dano
    VerificarFome(Player);

    printf("\nPressione qualquer tecla para retornar...");
    getch();
}
