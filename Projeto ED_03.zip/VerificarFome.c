#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include "Menu.h"
#include <unistd.h>

void VerificarFome(Jogador *Player)
{
    if (Player->Fome <= 0) {
        Player->Fome = 0;
        Player->Hp -= 15;
        printf("\n[ALERTA]Voce esta faminto e perdeu 15 de HP!\n");
        sleep(2);

        if (Player->Hp <= 0) {
            Player->Hp = 0;
            system("cls");
            printf("==================================================\n");
            printf("\n          VOCE MORREU DE FOME!           ");
            printf("\n==================================================\n");
            printf("\nPressione [ENTER] para fechar o jogo...");
            int tecla;
            do { tecla = getch(); } while (tecla != 13);
            exit(0);
        }
    }
}
