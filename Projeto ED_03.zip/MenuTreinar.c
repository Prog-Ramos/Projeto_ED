#include <stdio.h>
#include "Menu.h"
#include <stdlib.h>
#include <unistd.h>

void MenuTreinar(Jogador *Player)
{
    VerificarFome(Player);

    short int XpGanho;

    system("cls");
    printf("======================================================================================================\n");
    printf("   HP = %i/%i  ||  LEVEL = %i  ||  XP = %i/%i  ||  FOME = %i%%  ||  ENERGIA = %i%%  ||  MOEDAS = %i\n", Player->Hp,Player->HpMax,Player->Level, Player->Xp, Player->XpMax,Player->Fome,Player->Energia,Player->Moedas);
    printf("======================================================================================================\n");
    printf("\n================= CAMPO DE TREINAMENTO ================\n");
    if (Player->Energia >= 10&&Player->Fome>=5)
    {
        printf("\nTREINANDO");
        sleep(1);
        printf(".");
        sleep(1);
        printf(".");
        sleep(1);
        printf(".");
        sleep(1);
        system("cls");
        XpGanho=(Player->Level*3);//Xp em fun��o do nivel * 3.
        Player->Energia -= 10; //Energia consumida ao treinar
        Player->Xp +=XpGanho; //Soma XpGanhou;
        Player->Fome -=5; //Fome consumida ao treinar
        printf("======================================================================================================\n");
        printf("   HP = %i/%i  ||  LEVEL = %i  ||  XP = %i/%i  ||  FOME = %i%%  ||  ENERGIA = %i%%  ||  MOEDAS = %i\n", Player->Hp,Player->HpMax,Player->Level, Player->Xp, Player->XpMax,Player->Fome,Player->Energia,Player->Moedas);
        printf("======================================================================================================\n");
        printf("\n[Sucesso] Ap�s um longo dia de treino, voce se sente mais experiente, por�m com mais fome e cansado.\n");
    } else {
        printf("\n[Aviso] Para treinar voce precisa pelo menos de Energia:10%% Fome:5%% ! Descanse ou coma algo\n");//Os 2 %% s�o usados para exibir um % na tela.
    }
    printf("\n");
    system("pause");
}
