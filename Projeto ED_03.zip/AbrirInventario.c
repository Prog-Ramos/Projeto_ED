#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <string.h>
#include "Menu.h"

void AbrirInventario(Jogador *Player)
{
    int opcao;
    do {
        system("cls");
        printf("==================================================\n");
        printf("                   INVENTARIO                     \n");
        printf("==================================================\n");
        printf(" Status Atual -> HP: %i/%i | Fome: %i/100\n", Player->Hp, Player->HpMax, Player->Fome);
        printf("--------------------------------------------------\n");
        printf(" 1 - Pocão de HP: %i              [+30 HP]\n", Player->PocaoHp);
        printf(" 2 - Racão de Viagem: %i          [+30 Fome]\n", Player->Racao);
        printf(" 3 - Voltar\n");
        printf("==================================================\n");
        printf("Escolha um item para usar: ");
        scanf("%i", &opcao);

        switch(opcao) {
            case 1:
                if (Player->PocaoHp > 0) {
                    Player->PocaoHp--;
                    Player->Hp += 30;
                    if (Player->Hp > Player->HpMax) Player->Hp = Player->HpMax;
                    printf("\n> Voce usou uma Pocao de HP!\n");
                } else {
                    printf("\n> Voce nao tem Pocoes de HP!\n");
                }
                printf("\nPressione qualquer tecla para continuar...");
                getch();
                break;
            case 2:
                if (Player->Racao > 0) {
                    Player->Racao--;
                    Player->Fome += 30;
                    if (Player->Fome > 100) Player->Fome = 100;
                    printf("\n> Voce comeu uma Racao de Viagem!\n");
                } else {
                    printf("\n> Voce nao tem Racoes!\n");
                }
                printf("\nPressione qualquer tecla para continuar...");
                getch();
                break;
        }
    } while (opcao != 3);
}
