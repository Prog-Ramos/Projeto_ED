#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "Menu.h"

// --- DEFINI��ES DE CORES ANSI ---
#define RESET   "\x1B[0m"
#define VERMELHO "\x1B[31m"
#define VERDE    "\x1B[32m"
#define AMARELO  "\x1B[33m"
#define AZUL     "\x1B[34m"
#define CIANO    "\x1B[36m"
#define BRANCO   "\x1B[37m"

void MenuExplorar(Jogador *Player, BancoMonstros *NovoBancoMonstros,
                  Inventario *InventarioJogador, Missao *ListaMissoes)
{
    VerificarFome(Player);
    system("cls");

    printf(CIANO "======================================================================================================\n" RESET);
    printf("   HP = " VERMELHO "%i/%i" RESET "  ||  LEVEL = " AMARELO "%i" RESET "  ||  XP = " VERDE "%i/%i" RESET "  ||  FOME = " AMARELO "%i%%" RESET "  ||  ENERGIA = " AZUL "%i%%" RESET "  ||  MOEDAS = " AMARELO "%i" RESET "\n", Player->Hp,Player->HpMax,Player->Level, Player->Xp, Player->XpMax,Player->Fome,Player->Energia,Player->Moedas);
    printf(CIANO "======================================================================================================\n" RESET);

    int Escolha = 0;
    printf("\n" CIANO "================= EXPLORANDO =======================\n" RESET);
    printf(" " VERDE "1" RESET " - Procurar Monstros para Lutar\n");
    printf(" " VERDE "2" RESET " - Ir para uma cidade\n");
    printf(" " VERDE "3" RESET " - Voltar ao Menu Principal\n");
    printf(CIANO "==================================================\n" RESET);
    printf("Escolha: ");
    scanf("%d", &Escolha);

    switch(Escolha)
    {
        case 1:
            if(Player->Energia<20)
            {
                printf("\n" VERMELHO "[AVISO] Sua Energia e insuficiente! Energia atual: %d" RESET "\n",Player->Energia);
            }
            else
            {
                printf("\n" AMARELO "[Sistema]" RESET " Entrando em combate...\n");
                EncontraMonstro(Player, NovoBancoMonstros, ListaMissoes);
            }
            break;
        case 2:
            if(Player->Energia<20)
            {
                printf("\n" VERMELHO "[AVISO] Sua Energia e insuficiente! Energia atual: %d" RESET "\n",Player->Energia);
            }
            else
            {
                Cidade(Player, InventarioJogador);;
            }
            break;
        default:
            break;
    }
}
