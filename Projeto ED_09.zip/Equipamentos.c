#include <stdio.h>
#include "Inventario.h"
#include "BancoItens.h"

// --- DEFINIÇÕES DE CORES ANSI ---
#define RESET   "\x1B[0m"
#define VERMELHO "\x1B[31m"

void AdicionarEquipamentosIniciais(Jogador *Player, Inventario *InventarioJogador) //2a função chamada do inventario. Aqui adicionamos os itens iniciais
{
    int CodigoArma; //codigo da arma, que dependendo da classe escolhida, tera uma código.
    int CodigoArmadura; //codigo da armadura, que dependendo da classe escolhida, tera uma código.

    Item Arma; //struct que ira receber a Arma se for localizado o codigo
    Item Armadura;//struct que ira receber a Armadura se for localizado o codigo

    switch(Player->ClasseEscolhida) //aqui verificamos a classe escolhida e atribuimos os códigos.
    {
        case 1:
            CodigoArma = 1;
            CodigoArmadura = 16;
            break;

        case 2:
            CodigoArma = 11;
            CodigoArmadura = 16;
            break;

        case 3:
            CodigoArma = 31;
            CodigoArmadura = 16;
            break;

        default:
            printf(VERMELHO "Classe invalida!\n" RESET);
            return;
    }

    if(BuscarItemPorCodigo(CodigoArma, &Arma)) //passamos codigo da Arma e a struct Arma que ira receber todas os atributos.
    {
        AdicionaItem(Player, InventarioJogador, Arma); //Caso encontre o codigo da Arma adicionamos os dados de BancoItens na struct Arma
    }

    if(BuscarItemPorCodigo(CodigoArmadura, &Armadura)) //O mesmo acontece aqui, chamamos novamente a função para verificar se existe o codigo no banco de dados.
    {
        AdicionaItem(Player, InventarioJogador, Armadura);//Caso encontre o codigo da Armadura adicionamos os dados de BancoItens na struct Arma
    }
}
