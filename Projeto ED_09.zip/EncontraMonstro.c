#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <unistd.h>

#include "Menu.h"

// --- DEFINI  ES DE CORES ANSI ---
#define RESET   "\x1B[0m"
#define VERMELHO "\x1B[31m"
#define VERDE    "\x1B[32m"
#define AMARELO  "\x1B[33m"
#define AZUL     "\x1B[34m"
#define CIANO    "\x1B[36m"
#define BRANCO   "\x1B[37m"

void EncontraMonstro(Jogador *Player, BancoMonstros *NovoBancoMonstros, Missao *ListaMissoes)
{
    VerificarFome(Player);
    system("cls");
    //SORTEIO
    int n = rand() % 6;
    int Escolha;
    int Fuga = rand()%100;
    int tecla;

    Escolha=0;

    //BACKUP DO BESTIARIO
    Monstros MonstroBatalha = NovoBancoMonstros->lista[n];

    while(MonstroBatalha.Level>Player->Level)
    {
        n = rand() % 6;
        MonstroBatalha = NovoBancoMonstros->lista[n];
    }
    printf("\n" CIANO "========== "RESET VERMELHO "%s" RESET CIANO " - LEVEL = " RESET AMARELO "%d" RESET CIANO " ============\n", MonstroBatalha.Nome, MonstroBatalha.Level);
    printf(" " VERDE "1" RESET " - LUTAR\n");
    printf(" " VERDE "2" RESET " - FUGIR\n");
    printf("ESCOLHA: ");

    tecla=getch();

    Escolha=tecla-'0';

    while (tecla != '1' && tecla != '2')
    {
        system("cls");
        printf("\n" CIANO " ========== " RESET VERMELHO "%s" RESET CIANO " - LEVEL = " RESET AMARELO "%d" RESET CIANO " ============!\n", MonstroBatalha.Nome, MonstroBatalha.Level);
        printf("\n" VERMELHO "[ALERTA] Escolha incorreta!" RESET "\n");
        printf(" " VERDE "1" RESET " - Lutar\n");
        printf(" " VERDE "2" RESET " - Fugir\n");
        printf("Escolha: ");

        tecla=getch();

        Escolha=tecla-'0';
    }
    if(Escolha==2)
        {
            if(Fuga<30)
            {
                printf("\n" VERDE "[Sucesso] Voce Fugiu!!" RESET "\n");
                system("pause");
            }
            else
            {
                printf("\n" VERMELHO "[Alerta] Voce tenta fugir mas nao consegue.. Prepare-se para Lutar" RESET "\n");
                system("pause");
                Batalha(Player, &MonstroBatalha, ListaMissoes);
            }
        }
    else
    {
        Batalha(Player, &MonstroBatalha, ListaMissoes);
    }

}
