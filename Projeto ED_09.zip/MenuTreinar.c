#include <stdio.h>
#include "Menu.h"
#include <stdlib.h>
#include <unistd.h>

// --- DEFINI  ES DE CORES ANSI ---
#define RESET   "\x1B[0m"
#define VERMELHO "\x1B[31m"
#define VERDE    "\x1B[32m"
#define AMARELO  "\x1B[33m"
#define AZUL     "\x1B[34m"
#define CIANO    "\x1B[36m"
#define BRANCO   "\x1B[37m"

void MenuTreinar(Jogador *Player)
{
    VerificarFome(Player);

    short int XpGanho;

    system("cls");
    printf(CIANO "======================================================================================================\n" RESET);
    printf("   HP = " VERMELHO "%i/%i" RESET "  ||  LEVEL = " AMARELO "%i" RESET "  ||  XP = " VERDE "%i/%i" RESET "  ||  FOME = " AMARELO "%i%%" RESET "  ||  ENERGIA = " AZUL "%i%%" RESET "  ||  MOEDAS = " AMARELO "%i" RESET "\n", Player->Hp,Player->HpMax,Player->Level, Player->Xp, Player->XpMax,Player->Fome,Player->Energia,Player->Moedas);
    printf(CIANO "======================================================================================================\n" RESET);
    printf("\n" CIANO "================= CAMPO DE TREINAMENTO ================\n" RESET);

    if (Player->Energia >= 10&&Player->Fome>=5)
    {
        printf("\n" AMARELO "TREINANDO" RESET);
        sleep(1);
        printf(AMARELO "." RESET);
        sleep(1);
        printf(AMARELO "." RESET);
        sleep(1);
        printf(AMARELO "." RESET);
		sleep(1);
        system("cls");
        XpGanho=(Player->Level*3);//Xp em fun��o do nivel * 3.
        Player->Energia -= 10; //Energia consumida ao treinar
        Player->Xp +=XpGanho; //Soma XpGanhou;
        Player->Fome -=5; //Fome consumida ao treinar
        printf(CIANO "======================================================================================================\n" RESET);
        printf("   HP = " VERMELHO "%i/%i" RESET "  ||  LEVEL = " AMARELO "%i" RESET "  ||  XP = " VERDE "%i/%i" RESET "  ||  FOME = " AMARELO "%i%%" RESET "  ||  ENERGIA = " AZUL "%i%%" RESET "  ||  MOEDAS = " AMARELO "%i" RESET "\n", Player->Hp,Player->HpMax,Player->Level, Player->Xp, Player->XpMax,Player->Fome,Player->Energia,Player->Moedas);
        printf(CIANO "======================================================================================================\n" RESET);
        printf("\n" VERDE "[Sucesso]" RESET " Apos um longo dia de treino, voce se sente mais experiente, porem com mais fome e cansado.\n");
    } else {
        printf("\n" VERMELHO "[Aviso]" RESET " Para treinar voce precisa pelo menos de Energia: " AZUL "10%%" RESET " Fome: " AMARELO "5%%" RESET "! Descanse ou coma algo\n");//Os 2 %% s o usados para exibir um % na tela.
    }
    printf("\n");
    system("pause");
}
