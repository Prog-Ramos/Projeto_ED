#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#include "Jogador.h"
#include "Inventario.h"

// --- DEFINIÇÕES DE CORES ANSI ---
#define RESET   "\x1B[0m"
#define VERMELHO "\x1B[31m"
#define VERDE    "\x1B[32m"
#define AMARELO  "\x1B[33m"
#define AZUL     "\x1B[34m"
#define CIANO    "\x1B[36m"
#define BRANCO   "\x1B[37m"

void AbrirInventario(Jogador *Player, Inventario *InventarioJogador)
{
    int opcao;
    int i;

    do
    {
        system("cls");

        printf(CIANO "========================================\n" RESET);
        printf("           " BRANCO "INVENTARIO PESSOAL" RESET "           \n");
        printf(CIANO "========================================\n" RESET);

        printf("Espacos ocupados: " AMARELO "%i" RESET "/" CIANO "%i" RESET "\n\n",
               InventarioJogador->Quantidade,
               InventarioJogador->Capacidade);

        for(i = 0; i < InventarioJogador->Quantidade; i++)
        {
            printf("%i - %s\n", i + 1, InventarioJogador->itens[i].Nome);
        }

        printf("\n" CIANO "========================================" RESET "\n");
        printf("" VERDE "1" RESET " - Consumir item\n");
        printf("" VERDE "2" RESET " - Voltar\n");
        printf(CIANO "========================================\n" RESET);
        printf("Escolha: ");

        opcao = getch() - '0';

        switch(opcao)
        {
            case 1:
                ConsumirItem(Player, InventarioJogador);
                break;

            case 2:
                break;

            default:
                printf("\n" VERMELHO "Opcao invalida!" RESET "\n");
                system("pause");
                break;
        }

    } while(opcao != 2);
}
