#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include "Menu.h"
#include <unistd.h>

// --- DEFINIÇÕES DE CORES ANSI ---
#define RESET   "\x1B[0m"
#define VERMELHO "\x1B[31m"
#define VERDE    "\x1B[32m"
#define AMARELO  "\x1B[33m"
#define CIANO    "\x1B[36m"

void VerificarFome(Jogador *Player)
{
    Player->Fome-=5;
    if (Player->Fome <= 0)
    {
        Player->Fome = 0;
        Player->Hp -= 15;
        printf("\n" VERMELHO "[ALERTA] Voce esta faminto e perdeu 15 de HP!" RESET "\n");
        sleep(2);

        if (Player->Hp <= 0)
        {
            Player->Hp = 0;
            system("cls");
            printf(VERMELHO "\n==================================================" RESET);
            printf(VERMELHO "\n          VOCE MORREU DE FOME!           " RESET);
            printf(VERMELHO "\n==================================================\n" RESET);
            printf("\nPressione [" VERDE "ENTER" RESET "] para fechar o jogo...");
            int tecla;
            do { tecla = getch(); } while (tecla != 13);
            exit(0);
        }
    }
}
