#include <stdio.h>
#include <stdlib.h>
#include "Inventario.h"

// --- DEFINI  ES DE CORES ANSI ---
#define RESET   "\x1B[0m"
#define VERMELHO "\x1B[31m"
#define VERDE    "\x1B[32m"
#define AMARELO  "\x1B[33m"
#define AZUL     "\x1B[34m"
#define CIANO    "\x1B[36m"
#define BRANCO   "\x1B[37m"

void InicializaInventario(Inventario *inv) //1 fun��o do inventario. Ela recebe InventarioJogador da main. Esse � o invenario que vamos trabalhar.
{
    inv->Capacidade = 4; //capacidade inicial do personagem
    inv->Quantidade = 0; //nenhum item armazenado at� o momento

    inv->itens = malloc(inv->Capacidade * sizeof(Item)); //reservamos espa�o na mem�ria para 4 itens. O tipo que deve ser usado � o Item.
    //o ponteiro *itens, que � do tipo Item, aloca na memoria a capacidade de 4 * o tamanho da struct Item

    if (inv->itens == NULL) //verifica se foi possivel alocar.
    {
        printf(VERMELHO "Erro ao alocar memoria para o inventario!\n" RESET);
        exit(1);
    }
}

int AdicionaItem(Jogador *Player, Inventario *inv, Item novoItem) //aqui estamos passando novamente o ponteiro *inv do tipo Inventario. Caso seja possivel adicinar o item retorna 1 , do contrario, 0.
//Essa funcao poderia ser do tipo void, mas perderiamos a valida��o do que aconteceu se retornou 1 ou 0.
{
    if (inv->Quantidade >= inv->Capacidade) //se a quantidade de itens que ja tem no inventario for maior que a capacidade, significa que o inventario esta cheio.
    {
        printf(VERMELHO "Inventario cheio!\n" RESET);
        return 0; //retorna 0 pois esta cheio, assim podemos fazer uma valida��o.
    }

    inv->itens[inv->Quantidade] = novoItem; //Aqui � caso quantidade < capacidade. Nessa parte ele vai acessar o espa�o que alocamos com o malloc, e no primeiro indice que � quantidade = 0
    //ele ir� armazenar o primeiro item que � novoItem ( que veio da fun��o que chamou como arma ou armadura )

    Player->Atk+=novoItem.Atk; //Atualizamos o Player com os atributos do item adicionado.
    Player->Def+=novoItem.Def;//Atualizamos o Player com os atributos do item adicionado.

    inv->Quantidade++; //pula para o proximo indice do nosso espa�o alocado de itens[inv->quantidade]. O proximo sera armazenado em 1 e assim por diante.

    return 1; // 1 adicionou o item. 0 n�o adicionou

}

int AumentaInventario(Inventario *inv, int espacos) //Essa fun��o aumenta o inventario conforme os espa�os a serem aumentados, atribuindo em NovaCapacidade para um realloc.
{
    int NovaCapacidade;
    Item *aux;

    NovaCapacidade = inv->Capacidade + espacos;

    aux = realloc(inv->itens, NovaCapacidade * sizeof(Item)); //uso de realloc para aux, para verificarmos se � possivel atualizar a capacidade nova.

    if (aux == NULL) //VERIFICA SE O REALLOC FUNCIONOU.
    {
        printf(VERMELHO "Erro ao aumentar o inventario!\n" RESET);
        return 0;
    }

    inv->itens = aux; //passa a nova area alocada aux para itens que � o ponteiro *itens de invenario.
    inv->Capacidade = NovaCapacidade; //atualiza a capacidade do inventario, podendo armazenar mais itens.

    return 1;
}

void ExibirInventario(Inventario *inv)
{
    int i;

    printf("\n" CIANO "===== INVENTARIO =====" RESET "\n");

    for (i = 0; i < inv->Quantidade; i++)
    {
        printf("%d - %s\n", i + 1, inv->itens[i].Nome);
    }
    printf("\nEspacos ocupados: " AMARELO "%d" RESET, inv->Quantidade);
    printf("\nCapacidade: " CIANO "%d" RESET "\n", inv->Capacidade);
}

int ComprarMochila(Jogador *Player, Inventario *inv) //Essa funcao � chamada da loja para compra da mochila. Ela s� pode ser comprada 1 vez.
{
    int PrecoMochila = 300; //atribui valor da mochila para verificar se temos o dinheiro suficiente para comprar.

    if(Player->BolsaComprada == 1) //veirifica se Player j� possui a bolsa.
    {
        printf(AMARELO "Voce ja possui uma mochila!\n" RESET);
        return 0;
    }

    if(Player->Moedas < PrecoMochila) //Verifica se O Player consegue comprar a bolsa. Por ser um item especial, ela nao esta no banco de itens.
    {
        printf(VERMELHO "Moedas insuficientes!\n" RESET);
        return 0;
    }

    if(AumentaInventario(inv, 4)) //Chama a fun��o Aumenta inventario, passando como argumentos o inv que � o ponteiro que aponta para invetario do jogador e 4 que representa os espa�os que ira ser reallocado.
    //se a fun��o retornar 1 ele entra dentro do if j� com o inventario do jogador realocado.
    {
        Player->Moedas -= PrecoMochila; //desconta as moedas do jogador
        Player->BolsaComprada = 1; //atualiza para 1 BolsaComprada, assim o jogador n�o poder� comprar mais bolsas.

        printf(VERDE "Mochila comprada com sucesso!\n" RESET);
        printf("Capacidade do inventario: " CIANO "%d" RESET " espacos\n", inv->Capacidade);

        return 1;
    }

    printf(VERMELHO "Nao foi possivel comprar a mochila!\n" RESET); //Se mostrou essa mensagem, � por que n�o foi possivel alocar a nova �rea.
    return 0;
}

int RemoveItem(Jogador *Player, Inventario *inv, int posicao)//posicao recebe opcao - 1.
{
    int i;

    // Verifica se a posicao existe
    if(posicao < 0 || posicao >= inv->Quantidade)
    {
        return 0;
    }

    // Retira os atributos fornecidos pelo item
    Player->Atk -= inv->itens[posicao].Atk;
    Player->Def -= inv->itens[posicao].Def;

    // Desloca os itens seguintes uma posicao para tras
    for(i = posicao; i < inv->Quantidade - 1; i++)
    {
        inv->itens[i] = inv->itens[i + 1]; //copia o item da frente para a posi��o a ser removida, come�ando a partir da posi��o do item a ser removido
    }

    // Diminui a quantidade de itens armazenados
    inv->Quantidade--;

    return 1; //retorna 1 para etnrar dentro do if para da funcao que chamou.
}
void ConsumirItem(Jogador *Player, Inventario *inv)
{
    int opcao;
    Item Produto;

    system("cls");

    printf(CIANO "============================================\n" RESET);
    printf("             " BRANCO "CONSUMIR ITEM" RESET "                  \n");
    printf(CIANO "============================================\n" RESET);

    if(inv->Quantidade == 0)
    {
        printf("\n" AMARELO "Seu inventario esta vazio!" RESET "\n");
        system("pause");
        return;
    }

    printf("\n" AMARELO "ITENS DISPONIVEIS:" RESET "\n");

    for(int i = 0; i < inv->Quantidade; i++)
    {
        if(inv->itens[i].Tipo == 3 || inv->itens[i].Tipo == 4)
        {
            printf("\n" VERDE "%d" RESET " - %s", i + 1, inv->itens[i].Nome);

            if(inv->itens[i].RecuperaHp > 0)
            {
                printf(" | Recupera HP: " VERMELHO "+%d" RESET, inv->itens[i].RecuperaHp);
            }

            if(inv->itens[i].RecuperaFome > 0)
            {
                printf(" | Recupera Fome: " AMARELO "+%d" RESET, inv->itens[i].RecuperaFome);
            }

            printf("\n");
        }
    }

    printf("\n" VERMELHO "0" RESET " - Voltar");
    printf("\nEscolha o item que deseja consumir: ");

    if(scanf("%d", &opcao) != 1)
    {
        printf("\n" VERMELHO "Entrada invalida!" RESET "\n");

        while(getchar() != '\n');

        system("pause");
        return;
    }

    if(opcao == 0)
    {
        return;
    }

    if(opcao < 1 || opcao > inv->Quantidade)
    {
        printf("\n" VERMELHO "Opcao invalida!" RESET "\n");
        system("pause");
        return;
    }

    Produto = inv->itens[opcao - 1];

    if(Produto.Tipo != 3 && Produto.Tipo != 4)
    {
        printf("\n" VERMELHO "Esse item nao pode ser consumido!" RESET "\n");
        system("pause");
        return;
    }

    if(Produto.RecuperaHp > 0)
    {
        if(Player->Hp >= Player->HpMax)
        {
            printf("\n" AMARELO "Seu HP ja esta cheio!" RESET "\n");
            system("pause");
            return;
        }

        Player->Hp += Produto.RecuperaHp;

        if(Player->Hp > Player->HpMax)
        {
            Player->Hp = Player->HpMax;
        }
    }

    if(Produto.RecuperaFome > 0)
    {
        if(Player->Fome >= 100)
        {
            printf("\n" AMARELO "Sua fome ja esta totalmente recuperada!" RESET "\n");
            system("pause");
            return;
        }

        Player->Fome += Produto.RecuperaFome;

        if(Player->Fome > 100)
        {
            Player->Fome = 100;
        }
    }

    RemoveItem(Player, inv, opcao - 1);

    printf("\n" VERDE "Voce consumiu: %s" RESET "\n", Produto.Nome);
    printf("HP atual: " VERMELHO "%d/%d" RESET "\n", Player->Hp, Player->HpMax);
    printf("Fome atual: " AMARELO "%d%%" RESET "\n", Player->Fome);

    system("pause");
}
