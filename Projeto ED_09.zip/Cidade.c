#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <unistd.h>

#include "Menu.h"

// --- DEFINIÇÕES DE CORES ANSI ---
#define RESET   "\x1B[0m"
#define VERMELHO "\x1B[31m"
#define VERDE    "\x1B[32m"
#define AMARELO  "\x1B[33m"
#define AZUL     "\x1B[34m"
#define CIANO    "\x1B[36m"
#define BRANCO   "\x1B[37m"
#define BG_AZUL  "\x1B[44m" // Fundo Azul

void Cidade(Jogador *Player, Inventario *InventarioJogador)
{
    system("cls");

    VerificarFome(Player);

    // Divisória em Ciano, HP em Vermelho, Level/Fome/Moedas em Amarelo, XP em Verde e Energia em Azul
    printf(CIANO "======================================================================================================\n" RESET);
    printf("   HP = " VERMELHO "%i/%i" RESET "  ||  LEVEL = " AMARELO "%i" RESET "  ||  XP = " VERDE "%i/%i" RESET "  ||  FOME = " AMARELO "%i%%" RESET "  ||  ENERGIA = " AZUL "%i%%" RESET "  ||  MOEDAS = " AMARELO "%i" RESET "\n",
           Player->Hp, Player->HpMax, Player->Level, Player->Xp, Player->XpMax,
           Player->Fome, Player->Energia, Player->Moedas);
    printf(CIANO "======================================================================================================\n" RESET);

    printf("\n" AMARELO "[SISTEMA] Voce chegou na cidade, porem gastou energia!" RESET "\n");

    Player->Energia -= 10;

    if(Player->Energia < 0)
    {
        Player->Energia = 0;
    }

    system("pause");

    int opcao;

    if(Player->Energia >= 10)
    {
        do
        {
            system("cls");

            printf(CIANO "======================================================================================================\n" RESET);
            printf("   HP = " VERMELHO "%i/%i" RESET "  ||  LEVEL = " AMARELO "%i" RESET "  ||  XP = " VERDE "%i/%i" RESET "  ||  FOME = " AMARELO "%i%%" RESET "  ||  ENERGIA = " AZUL "%i%%" RESET "  ||  MOEDAS = " AMARELO "%i" RESET "\n",
                   Player->Hp, Player->HpMax, Player->Level, Player->Xp, Player->XpMax,
                   Player->Fome, Player->Energia, Player->Moedas);
            printf(CIANO "======================================================================================================\n" RESET);

            // Caixa de boas-vindas colorida
            printf(CIANO "==================================================\n" RESET);
            printf("               " BRANCO BG_AZUL "BEM-VINDO A CIDADE" RESET "                 \n");
            printf(CIANO "==================================================\n" RESET);
            printf(" " VERDE "1" RESET " - Descansar na Estalagem (Cura Tudo) [" VERMELHO "-40 Moedas" RESET "]\n");
            printf(" " VERDE "2" RESET " - Comer na Taberna (Enche a Fome)    [" VERMELHO "-20 Moedas" RESET "]\n");
            printf(" " VERDE "3" RESET " - Visitar o Mercado (Loja de Itens)\n");
            printf(" " VERDE "4" RESET " - Abrir Inventario Pessoal\n");
            printf(" " VERDE "5" RESET " - Sair da Cidade (Voltar ao Menu)\n");
            printf(CIANO "==================================================\n" RESET);

            printf("Escolha uma opcao: ");

            opcao = getch() - '0';

            printf("%i\n", opcao);

            if(opcao < 1 || opcao > 5)
            {
                printf("\n" VERMELHO "Opcao invalida!" RESET "\n");
                system("pause");
                continue;
            }

            switch(opcao)
            {
                case 1:
                    // Descansar na estalagem
                    break;

                case 2:
                    // Comer na taberna
                    break;

                case 3:
                    Loja(Player, InventarioJogador);
                    break;

                case 4:
                    AbrirInventario(Player, InventarioJogador);
                    break;

                case 5:
                    printf("\nSaindo da cidade...\n");
                    break;
            }

        } while(opcao != 5);
    }
    else
    {
        printf("\n" VERMELHO "Voce esta sem energia para ir ate a cidade! Faca um acampamento para se recuperar!" RESET "\n");
        system("pause");
    }
}

