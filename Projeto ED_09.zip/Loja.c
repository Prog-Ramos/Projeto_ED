#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#include "Menu.h"
#include "BancoItens.h"

// --- DEFINIÇÕES DE CORES ANSI ---
#define RESET   "\x1B[0m"
#define VERMELHO "\x1B[31m"
#define VERDE    "\x1B[32m"
#define AMARELO  "\x1B[33m"
#define AZUL     "\x1B[34m"
#define CIANO    "\x1B[36m"
#define BRANCO   "\x1B[37m"

void VenderItem(Jogador *Player, Inventario *InventarioJogador)
{
    int i;
    int opcao;
    Item Produto;

    system("cls");

    printf(CIANO "============================================\n" RESET);
    printf("                " BRANCO "VENDA DE ITENS" RESET "              \n");
    printf(CIANO "============================================\n" RESET);

    if(InventarioJogador->Quantidade == 0) //inventario vazio. Nao tem nada para vender.
    {
        printf("\n" AMARELO "Seu inventario esta vazio!" RESET "\n");
        system("pause");
        return;
    }

    for(i = 0; i < InventarioJogador->Quantidade; i++) //Exibi os itens do invetario e o codigo para selecionar a venda.
    {
        printf("\n" VERDE "%d" RESET " - %s", i + 1, InventarioJogador->itens[i].Nome);
        printf("\n    Valor de venda: " AMARELO "%d moedas" RESET "\n",
               InventarioJogador->itens[i].PrecoVenda);
    }

    printf("\n" VERMELHO "0" RESET " - Voltar");
    printf("\n\nEscolha o item que deseja vender: ");

    if(scanf("%d", &opcao) != 1)//Se a entrada foi uma letra ele da invalida.
    {
        printf("\n" VERMELHO "Entrada invalida!" RESET "\n");

        while(getchar() != '\n');

        system("pause");
        return;
    }

    if(opcao == 0)
    {
        return;
    }

    if(opcao < 1 || opcao > InventarioJogador->Quantidade) //o range da escolha foi maior do que a permitida.
    {
        printf("\n" VERMELHO "Opcao invalida!" RESET "\n");
        system("pause");
        return;
    }

    Produto = InventarioJogador->itens[opcao - 1]; //estamos copiando o item antes de remover !!
    //o menos 1 é por que o nosso vetor comeca no indice 0.

    if(RemoveItem(Player, InventarioJogador, opcao - 1))//chama a função para remover item e passa opcao - 1 pois o indice comeca em 0.
    {
        Player->Moedas += Produto.PrecoVenda; //recebe o valor de produto.

        printf("\n" VERDE "Item vendido com sucesso!" RESET "\n");
        printf("Item: %s\n", Produto.Nome);
        printf("Voce recebeu: " AMARELO "%d moedas" RESET "\n", Produto.PrecoVenda);
        printf("Moedas atuais: " AMARELO "%d" RESET "\n", Player->Moedas);
    }
    else
    {
        printf("\nItem não localizado"); //pouco provável que entremos nesse else, pois já foi verificado acima, porém, por motivos de organização, se entrou nesse else é por que
        //a posição não foi localizada.
    }
    system("pause");
}

void ComprarProduto(Jogador *Player, Inventario *InventarioJogador, int Tipo)
{
    int CodigoEscolhido;
    Item Produto;

    printf("\nDigite o codigo do produto que deseja comprar (" VERMELHO "0 para voltar" RESET "): ");

    if(scanf("%d", &CodigoEscolhido) != 1)
    {
        printf("\n" VERMELHO "Entrada invalida!" RESET "\n");

        while(getchar() != '\n');

        system("pause");
        return;
    }

    if(CodigoEscolhido == 0)
    {
        return;
    }

    if(!BuscarItemPorCodigo(CodigoEscolhido, &Produto))
    {
        printf("\n" VERMELHO "Produto nao encontrado!" RESET "\n");
        system("pause");
        return;
    }

    if(Produto.Tipo != Tipo)
    {
        printf("\n" VERMELHO "Esse produto nao pertence a categoria selecionada!" RESET "\n");
        system("pause");
        return;
    }

    if(Player->Moedas < Produto.PrecoCompra)
    {
        printf("\n" VERMELHO "Moedas insuficientes!" RESET "\n");
        system("pause");
        return;
    }

    if(AdicionaItem(Player, InventarioJogador, Produto))
    {
        Player->Moedas -= Produto.PrecoCompra;

        printf("\n" VERDE "Compra realizada com sucesso!" RESET "\n");
        printf("Voce comprou: %s\n", Produto.Nome);
        printf("Moedas restantes: " AMARELO "%d" RESET "\n", Player->Moedas);
    }

    system("pause");
}

void ExibirProdutos(Jogador *Player, Inventario *InventarioJogador, int Tipo)
{
    int i;
    Item Produto;

    system("cls");

    printf(CIANO "============================================\n" RESET);
    printf("              " BRANCO "PRODUTOS DA LOJA" RESET "              \n");
    printf(CIANO "============================================\n" RESET);

    for(i = 0; i < QuantidadeItens(); i++)
    {
        if(BuscarItemPorIndice(i, &Produto))
        {
            if(Produto.Tipo == Tipo)
            {
                printf("\nCodigo: " VERDE "%d" RESET, Produto.Codigo);
                printf("\nNome: %s", Produto.Nome);
                printf("\nPreco: " AMARELO "%d moedas" RESET, Produto.PrecoCompra);
                // Exibe somente os atributos que o item melhora
                if(Produto.Atk > 0)
                {
                    printf("\nAtaque: " AMARELO "+%d" RESET, Produto.Atk);
                }

                if(Produto.Def > 0)
                {
                    printf("\nDefesa: " AZUL "+%d" RESET, Produto.Def);
                }

                if(Produto.RecuperaHp > 0)
                {
                    printf("\nRecuperacao de HP: " VERMELHO "+%d" RESET, Produto.RecuperaHp);
                }

                if(Produto.RecuperaFome > 0)
                {
                    printf("\nRecuperacao de Fome: " AMARELO "+%d" RESET, Produto.RecuperaFome);
                }
                printf("\n" CIANO "--------------------------------------------" RESET "\n");
            }
        }
    }

    ComprarProduto(Player, InventarioJogador, Tipo);
}

// Menu principal da loja
void Loja(Jogador *Player, Inventario *InventarioJogador)
{
    int opcao;

    do
    {
        system("cls");

        printf(CIANO "========================================\n" RESET);
        printf("                 " BRANCO "MERCADO" RESET "                \n");
        printf(CIANO "========================================\n" RESET);
        printf(" MOEDAS DISPONIVEIS: " AMARELO "%i" RESET "\n", Player->Moedas);
        printf(CIANO "----------------------------------------\n" RESET);
        printf(" " VERDE "1" RESET " - Armas\n");
        printf(" " VERDE "2" RESET " - Armaduras\n");
        printf(" " VERDE "3" RESET " - Pocoes de HP\n");
        printf(" " VERDE "4" RESET " - Alimentos\n");
        printf(" " VERDE "5" RESET " - Mochila (+4 espacos) - " AMARELO "300 moedas" RESET "\n");
        printf(" " VERDE "6" RESET " - Vender itens\n");
        printf(" " VERDE "7" RESET " - Voltar para a cidade\n");
        printf(CIANO "========================================\n" RESET);

        printf("Escolha uma opcao: ");

        opcao = getch() - '0';

        switch(opcao)
        {
            case 1:
                ExibirProdutos(Player, InventarioJogador, 1);
                break;

            case 2:
                ExibirProdutos(Player, InventarioJogador, 2);
                break;

            case 3:
                ExibirProdutos(Player, InventarioJogador, 3);
                break;

            case 4:
                ExibirProdutos(Player, InventarioJogador, 4);
                break;

            case 5:
                ComprarMochila(Player, InventarioJogador);
                system("pause");
                break;

            case 6:
                VenderItem(Player, InventarioJogador);
                break;

            case 7:
                printf("\nVoltando para a cidade...\n");
                break;

            default:
                printf("\n" VERMELHO "Opcao invalida!" RESET "\n");
                system("pause");
                break;
        }

    } while(opcao != 7);
}


