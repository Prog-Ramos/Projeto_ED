#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <unistd.h>

#include "Menu.h"

// --- DEFINIÇÕES DE CORES ANSI ---
#define RESET   "\x1B[0m"
#define VERMELHO "\x1B[31m"
#define VERDE    "\x1B[32m"
#define AMARELO  "\x1B[33m"
#define AZUL     "\x1B[34m"
#define CIANO    "\x1B[36m"
#define BRANCO   "\x1B[37m"

void MenuStatus(Jogador *Player)
{
    int tecla;

    if(Player->Atributo>0)
    {
        system("cls");
        printf(CIANO "==================================================\n" RESET);
        printf("                " BRANCO "FICHA DO PERSONAGEM" RESET "               \n");
        printf(CIANO "==================================================\n" RESET);

        printf("Nome: %s\n", Player->Nome);
        printf("Classe: " CIANO "%s" RESET "\n", Player->Classe);
        printf("Level: " AMARELO "%d" RESET " | XP: " VERDE "%d/%d" RESET "\n",Player->Level,Player->Xp,Player->XpMax);
        printf("HP: " VERMELHO "%d/%d" RESET "\n", Player->Hp, Player->HpMax);
        printf("Ataque: " AMARELO "%d" RESET " | Defesa: " AZUL "%d" RESET "\n", Player->Atk, Player->Def);
        printf("Energia: " AZUL "%d%%" RESET " | Fome: " AMARELO "%d%%" RESET "\n", Player->Energia, Player->Fome);
        printf("Moedas: " AMARELO "%d GP" RESET "\n", Player->Moedas);
        printf("Atributos: " VERDE "%d" RESET "\n",Player->Atributo);
        printf(CIANO "==================================================\n" RESET);

        printf("\nVoce possui " VERDE "%d" RESET " atributos, deseja usar ?\n",Player->Atributo);
        printf(" " VERDE "1" RESET " - Usar Atributo\n");
        printf(" " VERDE "2" RESET " - Voltar para menu\n");
        printf("\nESCOLHA: ");

        tecla=getch();

        while (tecla != '1' && tecla != '2')
        {
            system("cls");
            printf(CIANO "==================================================\n" RESET);
            printf("                " BRANCO "FICHA DO PERSONAGEM" RESET "               \n");
            printf(CIANO "==================================================\n" RESET);

            printf("Nome: %s\n", Player->Nome);
            printf("Classe: " CIANO "%s" RESET "\n", Player->Classe);
            printf("Level: " AMARELO "%d" RESET " | XP: " VERDE "%d/%d" RESET "\n",Player->Level, Player->Xp,Player->XpMax);
            printf("HP: " VERMELHO "%d/%d" RESET "\n", Player->Hp, Player->HpMax);
            printf("Ataque: " AMARELO "%d" RESET " | Defesa: " AZUL "%d" RESET "\n", Player->Atk, Player->Def);
            printf("Energia: " AZUL "%d%%" RESET " | Fome: " AMARELO "%d%%" RESET "\n", Player->Energia, Player->Fome);
            printf("Moedas: " AMARELO "%d GP" RESET "\n", Player->Moedas);
            printf("Atributos: " VERDE "%d" RESET "\n",Player->Atributo);
            printf(CIANO "==================================================\n" RESET);

            printf("\n" VERMELHO "[ALERTA] Escolha incorreta!" RESET "\n");
            printf(" " VERDE "1" RESET " - Usar Atributo\n");
            printf(" " VERDE "2" RESET " - Voltar para menu\n");
            printf("\nESCOLHA: ");

            tecla=getch();


        }
        if(tecla=='1')
        {
            while(Player->Atributo>0)
            {
                printf("\nEscolha onde aplicar o seu atributo\n");
                printf("\n" VERDE "1" RESET " - ATAQUE");
                printf("\n" VERDE "2" RESET " - DEFESA");
                printf("\nESCOLHA: ");

                tecla=getch();

                while (tecla != '1' && tecla != '2')
                {
                    system("cls");
                    printf(CIANO "==================================================\n" RESET);
                    printf("                " BRANCO "FICHA DO PERSONAGEM" RESET "               \n");
                    printf(CIANO "==================================================\n" RESET);

                    printf("Nome: %s\n", Player->Nome);
                    printf("Classe: " CIANO "%s" RESET "\n", Player->Classe);
                    printf("Level: " AMARELO "%d" RESET " | XP: " VERDE "%d/%d" RESET "\n",Player->Level, Player->Xp,Player->XpMax);
                    printf("HP: " VERMELHO "%d/%d" RESET "\n", Player->Hp, Player->HpMax);
                    printf("Ataque: " AMARELO "%d" RESET " | Defesa: " AZUL "%d" RESET "\n", Player->Atk, Player->Def);
                    printf("Energia: " AZUL "%d%%" RESET " | Fome: " AMARELO "%d%%" RESET "\n", Player->Energia, Player->Fome);
                    printf("Moedas: " AMARELO "%d GP" RESET "\n", Player->Moedas);
                    printf("Atributos: " VERDE "%d" RESET "\n",Player->Atributo);
                    printf(CIANO "==================================================\n" RESET);

                    printf("\n" VERMELHO "[ALERTA] Escolha incorreta!" RESET "\n");
                    printf("\n" VERDE "1" RESET " - ATAQUE");
                    printf("\n" VERDE "2" RESET " - DEFESA");
                    printf("\nESCOLHA: ");

                    tecla=getch();


                }
                switch(tecla)
                {
                    case '1':
                        {
                            Player->Atk+=1;
                            Player->Atributo-=1;
                            system("cls");
                            printf(CIANO "==================================================\n" RESET);
                            printf("                " BRANCO "FICHA DO PERSONAGEM" RESET "               \n");
                            printf(CIANO "==================================================\n" RESET);

                            printf("Nome: %s\n", Player->Nome);
                            printf("Classe: " CIANO "%s" RESET "\n", Player->Classe);
                            printf("Level: " AMARELO "%d" RESET " | XP: " VERDE "%d/%d" RESET "\n",Player->Level, Player->Xp,Player->XpMax);
                            printf("HP: " VERMELHO "%d/%d" RESET "\n", Player->Hp, Player->HpMax);
                            printf("Ataque: " AMARELO "%d" RESET " | Defesa: " AZUL "%d" RESET "\n", Player->Atk, Player->Def);
                            printf("Energia: " AZUL "%d%%" RESET " | Fome: " AMARELO "%d%%" RESET "\n", Player->Energia, Player->Fome);
                            printf("Moedas: " AMARELO "%d GP" RESET "\n", Player->Moedas);
                            printf("Atributos: " VERDE "%d" RESET "\n",Player->Atributo);
                            printf(CIANO "==================================================\n" RESET);
                            break;
                        }
                    case '2':
                        {
                            Player->Def+=1;
                            Player->Atributo-=1;
                            system("cls");
                            printf(CIANO "==================================================\n" RESET);
                            printf("                " BRANCO "FICHA DO PERSONAGEM" RESET "               \n");
                            printf(CIANO "==================================================\n" RESET);

                            printf("Nome: %s\n", Player->Nome);
                            printf("Classe: " CIANO "%s" RESET "\n", Player->Classe);
                            printf("Level: " AMARELO "%d" RESET " | XP: " VERDE "%d/%d" RESET "\n",Player->Level, Player->Xp,Player->XpMax);
                            printf("HP: " VERMELHO "%d/%d" RESET "\n", Player->Hp, Player->HpMax);
                            printf("Ataque: " AMARELO "%d" RESET " | Defesa: " AZUL "%d" RESET "\n", Player->Atk, Player->Def);
                            printf("Energia: " AZUL "%d%%" RESET " | Fome: " AMARELO "%d%%" RESET "\n", Player->Energia, Player->Fome);
                            printf("Moedas: " AMARELO "%d GP" RESET "\n", Player->Moedas);
                            printf("Atributos: " VERDE "%d" RESET "\n",Player->Atributo);
                            printf(CIANO "==================================================\n" RESET);
                            break;
                        }

                }

                if(Player->Atributo==0)
                {
                    break;
                }
                else
                {
                    printf("\nVoce ainda possui " VERDE "%d" RESET " atributos, deseja continuar usando ? ",Player->Atributo);
                    printf("\n" VERDE "1" RESET " - SIM");
                    printf("\n" VERMELHO "2" RESET " - VOLTAR AO MENU");
                    printf("\nESCOLHA: ");
                    tecla=getch();

                    while (tecla != '1' && tecla != '2')
                    {
                        printf("\n" VERMELHO "[ALERTA] Escolha incorreta!" RESET "\n");
                        printf("\n" VERDE "1" RESET " - SIM");
                        printf("\n" VERMELHO "2" RESET " - VOLTAR AO MENU");
                        printf("\nESCOLHA: ");

                        tecla=getch();

                    }

                    if(tecla=='2')
                    {
                        return;
                    }

                }

            }

        }

    }
    if(Player->Atributo==0)
    {
        system("cls");
        printf(CIANO "==================================================\n" RESET);
        printf("                " BRANCO "FICHA DO PERSONAGEM" RESET "               \n");
        printf(CIANO "==================================================\n" RESET);

        printf("Nome: %s\n", Player->Nome);
        printf("Classe: " CIANO "%s" RESET "\n", Player->Classe);
        printf("Level: " AMARELO "%d" RESET " | XP: " VERDE "%d/%d" RESET "\n",Player->Level, Player->Xp,Player->XpMax);
        printf("HP: " VERMELHO "%d/%d" RESET "\n", Player->Hp, Player->HpMax);
        printf("Ataque: " AMARELO "%d" RESET " | Defesa: " AZUL "%d" RESET "\n", Player->Atk, Player->Def);
        printf("Energia: " AZUL "%d%%" RESET " | Fome: " AMARELO "%d%%" RESET "\n", Player->Energia, Player->Fome);
        printf("Moedas: " AMARELO "%d GP" RESET "\n", Player->Moedas);
        printf("Atributos: " VERDE "%d" RESET "\n",Player->Atributo);
        printf(CIANO "==================================================\n" RESET);
        printf("\n" AMARELO "Voce nao possui nenhum atributo ! Evolua de nivel para conseguir atributos" RESET "\n");
        system("pause");
    }
}


