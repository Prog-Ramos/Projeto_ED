#include <stdio.h>
#include <stdlib.h>
#include "Inventario.h"


void InicializaInventario(Inventario *inv)
{
    inv->Capacidade = 4; //capacidade inicial do personagem
    inv->Quantidade = 0; //nenhum item armazenado at� o momento

    inv->itens = malloc(inv->Capacidade * sizeof(Item)); //reservamos espa�o na mem�ria para 4 itens. O tipo que deve ser usado � o Item.

    if (inv->itens == NULL)
    {
        printf("Erro ao alocar memoria para o inventario!\n");
        exit(1);
    }
}

int AdicionaItem(Jogador *Player, Inventario *inv, Item novoItem) //aqui estamos passando novamente o ponteiro *inv do tipo Inventario, e criando uma nova struc
{
    if (inv->Quantidade >= inv->Capacidade)
    {
        printf("Inventario cheio!\n");
        return 0;
    }

    inv->itens[inv->Quantidade] = novoItem;

    Player->Atk+=novoItem.Atk;
    Player->Def+=novoItem.Def;

    inv->Quantidade++;

    return 1; // 1 adicionou o item. 0 n�o adicionou

}

int AumentaInventario(Inventario *inv, int espacos)
{
    int NovaCapacidade;
    Item *aux;

    NovaCapacidade = inv->Capacidade + espacos;

    aux = realloc(inv->itens, NovaCapacidade * sizeof(Item));

    if (aux == NULL)
    {
        printf("Erro ao aumentar o inventario!\n");
        return 0;
    }

    inv->itens = aux;
    inv->Capacidade = NovaCapacidade;

    return 1;
}

void ExibirInventario(Inventario *inv)
{
    int i;

    printf("\n===== INVENTARIO =====\n");

    for (i = 0; i < inv->Quantidade; i++)
    {
        printf("%d - %s\n", i + 1, inv->itens[i].Nome);
    }

    printf("\nEspacos ocupados: %d", inv->Quantidade);
    printf("\nCapacidade: %d\n", inv->Capacidade);
}

int ComprarMochila(Jogador *Player, Inventario *inv)
{
    int PrecoMochila = 300;

    if(Player->BolsaComprada == 1)
    {
        printf("Voce ja possui uma mochila!\n");
        return 0;
    }

    if(Player->Moedas < PrecoMochila)
    {
        printf("Moedas insuficientes!\n");
        return 0;
    }

    if(AumentaInventario(inv, 4)) //0 falso e 1 verdadeiro
    {
        Player->Moedas -= PrecoMochila;
        Player->BolsaComprada = 1;

        printf("Mochila comprada com sucesso!\n");
        printf("Capacidade do inventario: %d espacos\n", inv->Capacidade);

        return 1;
    }

    printf("Nao foi possivel comprar a mochila!\n");
    return 0;
}

int RemoveItem(Jogador *Player, Inventario *inv, int posicao)
{
    int i;

    // Verifica se a posicao existe
    if(posicao < 0 || posicao >= inv->Quantidade)
    {
        return 0;
    }

    // Retira os atributos fornecidos pelo item
    Player->Atk -= inv->itens[posicao].Atk;
    Player->Def -= inv->itens[posicao].Def;

    // Desloca os itens seguintes uma posicao para tras
    for(i = posicao; i < inv->Quantidade - 1; i++)
    {
        inv->itens[i] = inv->itens[i + 1];
    }

    // Diminui a quantidade de itens armazenados
    inv->Quantidade--;

    return 1;
}
void ConsumirItem(Jogador *Player, Inventario *inv)
{
    int opcao;
    Item Produto;

    system("cls");

    printf("============================================\n");
    printf("             CONSUMIR ITEM                  \n");
    printf("============================================\n");

    if(inv->Quantidade == 0)
    {
        printf("\nSeu inventario esta vazio!\n");
        system("pause");
        return;
    }

    printf("\nITENS DISPONIVEIS:\n");

    for(int i = 0; i < inv->Quantidade; i++)
    {
        if(inv->itens[i].Tipo == 3 || inv->itens[i].Tipo == 4)
        {
            printf("\n%d - %s", i + 1, inv->itens[i].Nome);

            if(inv->itens[i].RecuperaHp > 0)
            {
                printf(" | Recupera HP: +%d", inv->itens[i].RecuperaHp);
            }

            if(inv->itens[i].RecuperaFome > 0)
            {
                printf(" | Recupera Fome: +%d", inv->itens[i].RecuperaFome);
            }

            printf("\n");
        }
    }

    printf("\n0 - Voltar");
    printf("\nEscolha o item que deseja consumir: ");

    if(scanf("%d", &opcao) != 1)
    {
        printf("\nEntrada invalida!\n");

        while(getchar() != '\n');

        system("pause");
        return;
    }

    if(opcao == 0)
    {
        return;
    }

    if(opcao < 1 || opcao > inv->Quantidade)
    {
        printf("\nOpcao invalida!\n");
        system("pause");
        return;
    }

    Produto = inv->itens[opcao - 1];

    if(Produto.Tipo != 3 && Produto.Tipo != 4)
    {
        printf("\nEsse item nao pode ser consumido!\n");
        system("pause");
        return;
    }

    if(Produto.RecuperaHp > 0)
    {
        if(Player->Hp >= Player->HpMax)
        {
            printf("\nSeu HP ja esta cheio!\n");
            system("pause");
            return;
        }

        Player->Hp += Produto.RecuperaHp;

        if(Player->Hp > Player->HpMax)
        {
            Player->Hp = Player->HpMax;
        }
    }

    if(Produto.RecuperaFome > 0)
    {
        if(Player->Fome >= 100)
        {
            printf("\nSua fome ja esta totalmente recuperada!\n");
            system("pause");
            return;
        }

        Player->Fome += Produto.RecuperaFome;

        if(Player->Fome > 100)
        {
            Player->Fome = 100;
        }
    }

    RemoveItem(Player, inv, opcao - 1);

    printf("\nVoce consumiu: %s\n", Produto.Nome);
    printf("HP atual: %d/%d\n", Player->Hp, Player->HpMax);
    printf("Fome atual: %d%%\n", Player->Fome);

    system("pause");
}
