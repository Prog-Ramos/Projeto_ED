#include <stdio.h>
#include <math.h>
#include <time.h>
#include <locale.h>
#include <stdlib.h>

#include "Monstros.h"
#include "Jogador.h"
#include "Menu.h"
#include "Inventario.h"
#include "Missoes.h"

int main()
{
    srand(time(NULL));

    setlocale(LC_ALL, "Portuguese");

    printf("================ BEM-VINDO AO RPG ================\n\n");

    Jogador Player = CriarJogador();

    Inventario InventarioJogador;

    InicializaInventario(&InventarioJogador);

    AdicionarEquipamentosIniciais(&Player, &InventarioJogador);

    BancoMonstros NovoBancoMonstros;

    InicializarMonstros(&NovoBancoMonstros);

    // Inicializando a lista de missoes
    Missao *ListaMissoes;

    ListaMissoes = InicializarMissoes();

    ExibirMenuPrincipal(&Player, &NovoBancoMonstros, &InventarioJogador, ListaMissoes);

    free(InventarioJogador.itens);

    return 0;
}
