
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#include "Menu.h"
#include "BancoItens.h"

void VenderItem(Jogador *Player, Inventario *InventarioJogador)
{
    int i;
    int opcao;
    Item Produto;

    system("cls");

    printf("============================================\n");
    printf("                VENDA DE ITENS              \n");
    printf("============================================\n");

    if(InventarioJogador->Quantidade == 0)
    {
        printf("\nSeu inventario esta vazio!\n");
        system("pause");
        return;
    }

    for(i = 0; i < InventarioJogador->Quantidade; i++)
    {
        printf("\n%d - %s", i + 1, InventarioJogador->itens[i].Nome);
        printf("\n    Valor de venda: %d moedas\n",
               InventarioJogador->itens[i].PrecoVenda);
    }

    printf("\n0 - Voltar");
    printf("\n\nEscolha o item que deseja vender: ");

    if(scanf("%d", &opcao) != 1)
    {
        printf("\nEntrada invalida!\n");

        while(getchar() != '\n');

        system("pause");
        return;
    }

    if(opcao == 0)
    {
        return;
    }

    if(opcao < 1 || opcao > InventarioJogador->Quantidade)
    {
        printf("\nOpcao invalida!\n");
        system("pause");
        return;
    }

    Produto = InventarioJogador->itens[opcao - 1]; //estamos copiando o item antes de remover !! Isso desloca o vetor

    if(RemoveItem(Player, InventarioJogador, opcao - 1))
    {
        Player->Moedas += Produto.PrecoVenda;

        printf("\nItem vendido com sucesso!\n");
        printf("Item: %s\n", Produto.Nome);
        printf("Voce recebeu: %d moedas\n", Produto.PrecoVenda);
        printf("Moedas atuais: %d\n", Player->Moedas);
    }

    system("pause");
}

void ComprarProduto(Jogador *Player, Inventario *InventarioJogador, int Tipo)
{
    int CodigoEscolhido;
    Item Produto;

    printf("\nDigite o codigo do produto que deseja comprar (0 para voltar): ");

    if(scanf("%d", &CodigoEscolhido) != 1)
    {
        printf("\nEntrada invalida!\n");

        while(getchar() != '\n');

        system("pause");
        return;
    }

    if(CodigoEscolhido == 0)
    {
        return;
    }

    if(!BuscarItemPorCodigo(CodigoEscolhido, &Produto))
    {
        printf("\nProduto nao encontrado!\n");
        system("pause");
        return;
    }

    if(Produto.Tipo != Tipo)
    {
        printf("\nEsse produto nao pertence a categoria selecionada!\n");
        system("pause");
        return;
    }

    if(Player->Moedas < Produto.PrecoCompra)
    {
        printf("\nMoedas insuficientes!\n");
        system("pause");
        return;
    }

    if(AdicionaItem(Player, InventarioJogador, Produto))
    {
        Player->Moedas -= Produto.PrecoCompra;

        printf("\nCompra realizada com sucesso!\n");
        printf("Voce comprou: %s\n", Produto.Nome);
        printf("Moedas restantes: %d\n", Player->Moedas);
    }

    system("pause");
}

void ExibirProdutos(Jogador *Player, Inventario *InventarioJogador, int Tipo)
{
    int i;
    Item Produto;

    system("cls");

    printf("============================================\n");
    printf("              PRODUTOS DA LOJA              \n");
    printf("============================================\n");

    for(i = 0; i < QuantidadeItens(); i++)
    {
        if(BuscarItemPorIndice(i, &Produto))
        {
            if(Produto.Tipo == Tipo)
            {
                printf("\nCodigo: %d", Produto.Codigo);
                printf("\nNome: %s", Produto.Nome);
                printf("\nPreco: %d moedas", Produto.PrecoCompra);
                // Exibe somente os atributos que o item melhora
                if(Produto.Atk > 0)
                {
                    printf("\nAtaque: +%d", Produto.Atk);
                }

                if(Produto.Def > 0)
                {
                    printf("\nDefesa: +%d", Produto.Def);
                }

                if(Produto.RecuperaHp > 0)
                {
                    printf("\nRecuperacao de HP: +%d", Produto.RecuperaHp);
                }

                if(Produto.RecuperaFome > 0)
                {
                    printf("\nRecuperacao de Fome: +%d", Produto.RecuperaFome);
                }
                printf("\n--------------------------------------------\n");
            }
        }
    }

    ComprarProduto(Player, InventarioJogador, Tipo);
}

// Menu principal da loja
void Loja(Jogador *Player, Inventario *InventarioJogador)
{
    int opcao;

    do
    {
        system("cls");

        printf("========================================\n");
        printf("                 MERCADO                \n");
        printf("========================================\n");
        printf(" MOEDAS DISPONIVEIS: %i\n", Player->Moedas);
        printf("----------------------------------------\n");
        printf(" 1 - Armas\n");
        printf(" 2 - Armaduras\n");
        printf(" 3 - Pocoes de HP\n");
        printf(" 4 - Alimentos\n");
        printf(" 5 - Mochila (+4 espacos) - 300 moedas\n");
        printf(" 6 - Vender itens\n");
        printf(" 7 - Voltar para a cidade\n");
        printf("========================================\n");

        printf("Escolha uma opcao: ");

        opcao = getch() - '0';

        switch(opcao)
        {
            case 1:
                ExibirProdutos(Player, InventarioJogador, 1);
                break;

            case 2:
                ExibirProdutos(Player, InventarioJogador, 2);
                break;

            case 3:
                ExibirProdutos(Player, InventarioJogador, 3);
                break;

            case 4:
                ExibirProdutos(Player, InventarioJogador, 4);
                break;

            case 5:
                ComprarMochila(Player, InventarioJogador);
                system("pause");
                break;

            case 6:
                VenderItem(Player, InventarioJogador);
                break;

            case 7:
                printf("\nVoltando para a cidade...\n");
                break;

            default:
                printf("\nOpcao invalida!\n");
                system("pause");
                break;
        }

    } while(opcao != 7);
}


