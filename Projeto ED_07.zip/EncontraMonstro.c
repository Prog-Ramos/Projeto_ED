#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <unistd.h>

#include "Menu.h"


void EncontraMonstro(Jogador *Player, BancoMonstros *NovoBancoMonstros, Missao *ListaMissoes)
{
    VerificarFome(Player);
    system("cls");
    //SORTEIO
    int n = rand() % 6;
    int Escolha;
    int Fuga = rand()%100;
    int tecla;

    Escolha=0;

    //BACKUP DO BESTIARIO
    Monstros MonstroBatalha = NovoBancoMonstros->lista[n];

    while(MonstroBatalha.Level>Player->Level)
    {
        n = rand() % 6;
        MonstroBatalha = NovoBancoMonstros->lista[n];
    }
    printf("\n========== %s - LEVEL = %d ============!\n", MonstroBatalha.Nome, MonstroBatalha.Level);
    printf("1 - LUTAR\n");
    printf("2 - FUGIR\n");
    printf("ESCOLHA: ");

    tecla=getch();

    Escolha=tecla-'0';

    while (tecla != '1' && tecla != '2')
    {
        system("cls");
        printf("\n========== %s - LEVEL = %d ============!\n", MonstroBatalha.Nome, MonstroBatalha.Level);
        printf("\n[ALERTA]Escolha incorreta!\n");
        printf("1 - Lutar\n");
        printf("2 - Fugir\n");
        printf("Escolha: ");

        tecla=getch();

        Escolha=tecla-'0';
    }
    if(Escolha==2)
        {
            if(Fuga<30)
            {
                printf("\n[Sucesso]Voce Fugiu!!\n");
                system("pause");
            }
            else
            {
                printf("\n[Alerta]Voce tenta fugir mas n�o consegue.. Prepare-se para Lutar\n");
                system("pause");
                Batalha(Player, &MonstroBatalha, ListaMissoes);
            }
        }
    else
    {
        Batalha(Player, &MonstroBatalha, ListaMissoes);
    }


}
