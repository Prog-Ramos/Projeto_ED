#include <stdio.h>
#include "Inventario.h"
#include "BancoItens.h"

void AdicionarEquipamentosIniciais(Jogador *Player, Inventario *InventarioJogador)
{
    int CodigoArma;
    int CodigoArmadura;

    Item Arma;
    Item Armadura;

    switch(Player->ClasseEscolhida)
    {
        case 1:
            CodigoArma = 1;
            CodigoArmadura = 16;
            break;

        case 2:
            CodigoArma = 11;
            CodigoArmadura = 16;
            break;

        case 3:
            CodigoArma = 31;
            CodigoArmadura = 16;
            break;

        default:
            printf("Classe invalida!\n");
            return;
    }

    if(BuscarItemPorCodigo(CodigoArma, &Arma))
    {
        AdicionaItem(Player, InventarioJogador, Arma);
    }

    if(BuscarItemPorCodigo(CodigoArmadura, &Armadura))
    {
        AdicionaItem(Player, InventarioJogador, Armadura);
    }
}
