#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#include "Jogador.h"
#include "Inventario.h"

void AbrirInventario(Jogador *Player, Inventario *InventarioJogador)
{
    int opcao;
    int i;

    do
    {
        system("cls");

        printf("========================================\n");
        printf("           INVENTARIO PESSOAL           \n");
        printf("========================================\n");

        printf("Espacos ocupados: %i/%i\n\n",
               InventarioJogador->Quantidade,
               InventarioJogador->Capacidade);

        for(i = 0; i < InventarioJogador->Quantidade; i++)
        {
            printf("%i - %s\n", i + 1, InventarioJogador->itens[i].Nome);
        }

        printf("\n========================================\n");
        printf("1 - Consumir item\n");
        printf("2 - Voltar\n");
        printf("========================================\n");
        printf("Escolha: ");

        opcao = getch() - '0';

        switch(opcao)
        {
            case 1:
                ConsumirItem(Player, InventarioJogador);
                break;

            case 2:
                break;

            default:
                printf("\nOpcao invalida!\n");
                system("pause");
                break;
        }

    } while(opcao != 2);
}
