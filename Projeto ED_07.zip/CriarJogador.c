#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>

#include "Jogador.h"

// FUN��O QUE RETORNA UMA STRUCT COM TODOS OS ATRIBUTOS PARA O JOGADOR;
Jogador CriarJogador()
{
    Jogador NovoJogador;
    int OpcaoClasse = 0;

    printf("DIGITE O NOME DO PERSONAGEM: ");
    // %20[^\n] limita a leitura a no m�ximo 20 caracteres para evitar bugs
    scanf(" %50[^\n]", NovoJogador.Nome);

    // Limpa o caractere 'Enter' (\n) que sobrou da leitura do nome
    while (getchar() != '\n');

    // AQUI FAZEMOS A ENTRADA DA CLASSE E VERIFICA��O COM PROTE��O;
    system("cls");
    do {
        printf("\n================= ESCOLHA A CLASSE ================\n");
        printf("1 - Guerreiro \t(100 HP, 5 ATK, 8 DEF)\n");
        printf("2 - Mago      \t(45 HP, 15 ATK, 2 DEF)\n");
        printf("3 - Arqueiro  \t(70 HP, 10 ATK, 4 DEF)\n");
        printf("\nESCOLHA: ");

        // Se o scanf N�O retornar 1, significa que o usu�rio digitou letras ou espa�os
        if (scanf("%d", &OpcaoClasse) != 1) {
            printf("\n[Erro] Entrada invalida! Digite apenas numeros.\n");

            // Esse la�o limpa TODAS as letras ou espa�os que ficaram presos no buffer do teclado
            while (getchar() != '\n');

            OpcaoClasse = 0; // For�a uma op��o inv�lida para repetir o do-while
            continue;
        }

        // Limpa o 'Enter' ap�s o n�mero ser digitado com sucesso
        while (getchar() != '\n');

        if (OpcaoClasse < 1 || OpcaoClasse > 3) {
            printf("Opcao invalida! Tente novamente.\n");
        }

    } while (OpcaoClasse < 1 || OpcaoClasse > 3);

    NovoJogador.ClasseEscolhida = OpcaoClasse;

    // ATRIBUI��O PADR�O PARA TODAS AS CLASSES
    NovoJogador.Energia = 100;
    NovoJogador.Fome = 105;
    NovoJogador.Level = 1;
    NovoJogador.Xp = 0;
    NovoJogador.XpMax = 100;
    NovoJogador.Moedas = 5000;
    NovoJogador.Atributo= 0;

    // ATRIBUI��O DA CLASSE NO PLAYER
    switch(NovoJogador.ClasseEscolhida)
    {
       case 1:
           NovoJogador.Hp = 100;
           NovoJogador.HpMax = 100;
           NovoJogador.Atk = 5;
           NovoJogador.Def = 8;
           strcpy(NovoJogador.Classe, "Guerreiro");
           break;
       case 2:
           NovoJogador.Hp = 45;
           NovoJogador.HpMax = 45;
           NovoJogador.Atk = 15;
           NovoJogador.Def = 2;
           strcpy(NovoJogador.Classe, "Mago");
           break;
       case 3:
           NovoJogador.Hp = 70;
           NovoJogador.HpMax = 70;
           NovoJogador.Atk = 10;
           NovoJogador.Def = 4;
           strcpy(NovoJogador.Classe, "Arqueiro");
           break;
    }

    system("cls");
    return NovoJogador;
}

