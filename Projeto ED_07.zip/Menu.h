#ifndef MENU_H
#define MENU_H

#include "Monstros.h"
#include "Jogador.h"
#include "Inventario.h"
#include "Missoes.h"


void ExibirMenuPrincipal(Jogador *Player, BancoMonstros *NovoBancoMonstros,
                         Inventario *InventarioJogador, Missao *ListaMissoes);

void MenuExplorar(Jogador *Player, BancoMonstros *NovoBancoMonstros,
                  Inventario *InventarioJogador, Missao *ListaMissoes);
void MenuStatus(Jogador *Player);
void MenuTreinar(Jogador *Player);
void EncontraMonstro(Jogador *Player, BancoMonstros *NovoBancoMonstros,
                     Missao *ListaMissoes);
void Cidade(Jogador *Player, Inventario *InventarioJogador);
void Batalha(Jogador *Player, Monstros *MonstroBatalha, Missao *ListaMissoes);

//Funções adicionadas
void VerificarFome(Jogador *Player);
void AbrirInventario(Jogador *Player, Inventario *InventarioJogador);
void Loja(Jogador *Player, Inventario *InventarioJogador);
void Acampar(Jogador *Player, BancoMonstros *NovoBancoMonstros, Missao *ListaMissoes);

//Funções adicinadas
void EvoluirLevel(Jogador *Player);

#endif


