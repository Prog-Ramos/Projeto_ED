
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

#include "Missoes.h"

// Insere uma nova missao no final da lista
Missao *InserirMissao(Missao *Inicio, int Codigo,
                      char Nome[], char Descricao[],
                      char MonstroAlvo[], int QuantidadeNecessaria,
                      int RecompensaXp, int Status)
{
    Missao *NovaMissao;
    Missao *aux;

    NovaMissao = malloc(sizeof(Missao));

    if(NovaMissao == NULL)
    {
        printf("Erro ao alocar memoria!\n");
        return Inicio;
    }

    NovaMissao->Codigo = Codigo;

    strcpy(NovaMissao->Nome, Nome);
    strcpy(NovaMissao->Descricao, Descricao);
    strcpy(NovaMissao->MonstroAlvo, MonstroAlvo);

    NovaMissao->QuantidadeNecessaria = QuantidadeNecessaria;
    NovaMissao->Progresso = 0;

    NovaMissao->RecompensaXp = RecompensaXp;

    NovaMissao->Status = Status;
    NovaMissao->prox = NULL;

    if(Inicio == NULL)
    {
        Inicio = NovaMissao;
    }
    else
    {
        aux = Inicio;

        while(aux->prox != NULL)
        {
            aux = aux->prox;
        }

        aux->prox = NovaMissao;
    }

    return Inicio;
}

// Inicializa as missoes do jogo
Missao *InicializarMissoes()
{
    Missao *Inicio = NULL;

    Inicio = InserirMissao(Inicio, 1, "A Cacada a Manticora",
                           "Derrote 5 Manticoras.",
                           "Manticora", 5, 100, 1);

    Inicio = InserirMissao(Inicio, 2, "A Ameaca das Quimeras",
                           "Derrote 3 Quimeras.",
                           "Quimera", 3, 200, 0);

    Inicio = InserirMissao(Inicio, 3, "O Enigma da Esfinge",
                           "Derrote 1 Esfinge.",
                           "Esfinge", 1, 350, 0);

    return Inicio;
}

// Exibe todas as missoes cadastradas
void ExibirMissoes(Missao *Inicio)
{
    Missao *aux;

    aux = Inicio;

    system("cls");

    printf("========================================\n");
    printf("                 MISSOES                \n");
    printf("========================================\n");

    while(aux != NULL)
    {
        printf("\nCodigo: %d", aux->Codigo);
        printf("\nMissao: %s", aux->Nome);
        printf("\nDescricao: %s", aux->Descricao);

        printf("\nProgresso: %d/%d",
               aux->Progresso, aux->QuantidadeNecessaria);

        printf("\nRecompensa: %d XP", aux->RecompensaXp);

        if(aux->Status == 0)
        {
            printf("\nStatus: BLOQUEADA");
        }
        else if(aux->Status == 1)
        {
            printf("\nStatus: DISPONIVEL");
        }
        else if(aux->Status == 2)
        {
            printf("\nStatus: CONCLUIDA");
        }

        printf("\n----------------------------------------");

        aux = aux->prox;
    }

    printf("\n\nPressione qualquer tecla para voltar...");
    getch();
}

// Atualiza o progresso quando um monstro e derrotado
void AtualizarProgresso(Missao *Inicio, char NomeMonstro[], Jogador *Player)
{
    Missao *aux;

    aux = Inicio;

    while(aux != NULL)
    {
        if(aux->Status == 1)
        {
            if(strcmp(aux->MonstroAlvo, NomeMonstro) == 0)
            {
                aux->Progresso++;

                printf("\n========================================");
                printf("\n       PROGRESSO DA MISSAO");
                printf("\n========================================");

                printf("\nMissao: %s", aux->Nome);

                printf("\nProgresso: %d/%d",
                       aux->Progresso, aux->QuantidadeNecessaria);

                if(aux->Progresso >= aux->QuantidadeNecessaria)
                {
                    aux->Status = 2;

                    // Entrega a recompensa de XP
                    Player->Xp += aux->RecompensaXp;

                    printf("\n\nMISSAO CONCLUIDA!");
                    printf("\nVoce recebeu %d XP!", aux->RecompensaXp);

                    // Desbloqueia a proxima missao
                    if(aux->prox != NULL)
                    {
                        aux->prox->Status = 1;

                        printf("\nNova missao desbloqueada: %s",
                               aux->prox->Nome);
                    }
                }

                printf("\n========================================\n");

                return;
            }
        }

        aux = aux->prox;
    }
}

