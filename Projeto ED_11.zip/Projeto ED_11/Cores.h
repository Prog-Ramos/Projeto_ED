#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

// --- CORES ANSI CENTRALIZADAS NO SEU PROJETO ---
#define RESET    "\x1B[0m"
#define VERMELHO "\x1B[31m"
#define VERDE    "\x1B[32m"
#define AMARELO  "\x1B[33m"
#define AZUL     "\x1B[34m"
#define CIANO    "\x1B[36m"
#define BRANCO   "\x1B[37m"
#define BG_AZUL  "\x1B[44m" // <-- Garanta que esta linha está aqui para o título da cidade funcionar!


#endif // MENU_H_INCLUDED
