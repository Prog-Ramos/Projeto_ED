
#ifndef BANCOITENS_H
#define BANCOITENS_H

#include "Inventario.h"

int QuantidadeItens();
int BuscarItemPorCodigo(int codigo, Item *itemEncontrado);
int BuscarItemPorIndice(int indice, Item *itemEncontrado);

#endif
