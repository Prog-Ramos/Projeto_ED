#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <unistd.h>

#include "Menu.h"

// --- DEFINI��ES DE CORES ANSI ---
#define RESET   "\x1B[0m"
#define VERMELHO "\x1B[31m"
#define VERDE    "\x1B[32m"
#define AMARELO  "\x1B[33m"
#define AZUL     "\x1B[34m"
#define CIANO    "\x1B[36m"
#define BRANCO   "\x1B[37m"

void Batalha(Jogador *Player, Monstros *MonstroBatalha, Missao *ListaMissoes)
{
    int DadoJogador;
    int DadoMonstro;
    int Resultado;
    int Escolha=1; //Como anteriormente o jogador escolheu Lutar, a escolha j� vem como 1.
    int Fuga;
    int DanoFuga;
    int tecla;
    int tentativasFuga = 0; // <-- NOVA VARI�VEL: Conta as tentativas de fuga nesta batalha

    while((Player->Hp > 0) && (MonstroBatalha->Hp > 0))
    {
        system("cls");

        printf(CIANO "==================================================\n" RESET);
        printf("   HP %s = " VERMELHO "%i" RESET "  ||  HP INIMIGO (%s) = " VERMELHO "%i" RESET "\n", Player->Nome, Player->Hp, MonstroBatalha->Nome, MonstroBatalha->Hp);
        printf(CIANO "==================================================\n" RESET);

        if(Escolha == 2)
        {

            Fuga = rand() % 100;

            // Condi��o modificada: Se a chance der certo OU se j� for a segunda (ou mais) tentativa
            if(Fuga < 20 || tentativasFuga >= 1)
            {
                printf("\n" VERDE "[SISTEMA] Voce Fugiu!!" RESET "\n");
                if(tentativasFuga >= 2) {
                    printf(AMARELO "[SISTEMA] (Fuga garantida por bravura!)" RESET "\n");
                }
                printf("\n" AMARELO "[SISTEMA]" RESET " Pressione [" VERDE "ENTER" RESET "] para continuar...");
                do { tecla = getch(); } while (tecla != 13);
                return;
            }
            else
            {
                tentativasFuga++; // Incrementa o n�mero de tentativas
                // Calcula o dado do monstro para a penalidade de fuga
                DadoMonstro = (rand() % 6) + 1;
                DanoFuga = DadoMonstro * MonstroBatalha->Atk;
                Player->Hp -= DanoFuga;

                if(Player->Hp < 0)
                {
                    Player->Hp = 0;
                }
                system("cls");
                printf(CIANO "==================================================\n" RESET);
                printf("   HP %s = " VERMELHO "%i" RESET "  ||  HP INIMIGO (%s) = " VERMELHO "%i" RESET "\n", Player->Nome, Player->Hp, MonstroBatalha->Nome, MonstroBatalha->Hp);
                printf(CIANO "==================================================\n" RESET);
                printf("\n" VERMELHO "[SISTEMA] VOCE TENTA FUGIR MAS NAO CONSEGUE!" RESET "\n");
                printf(VERMELHO "[SISTEMA] O INIMIGO CAUSOU %i DE DANO NA SUA TENTATIVA DE FUGA!" RESET "\n", DanoFuga);
                //printf("\[SISTEMA] O INIMIGO CAUSOU %i DE DANO NA SUA TENTATIVA DE FUGA!\n", DanoFuga);
                sleep(3);

                if(Player->Hp <= 0)
                {
                    system("cls");
                    printf(VERMELHO "==================================================\n" RESET);
                    printf(VERMELHO "\n                    GAME OVER                   \n" RESET);
                    printf(VERMELHO "\n==================================================\n" RESET);
                    printf("\n" AMARELO "[SISTEMA]" RESET " Pressione [" VERDE "ENTER" RESET "] para fechar o jogo...");
                    do { tecla = getch(); } while (tecla != 13);
                    exit(0);
                }
                else
                {
                    printf("\n" AMARELO "[SISTEMA]" RESET " A proxima tentativa de fuga sera " VERDE "100%% garantida!" RESET "\n"); // Aviso ao jogador
                }
                // Se o jogador morreu tentando fugir, verifica aqui
                system("pause");
            }
        }

        // 2. Se escolheu Lutar (Op��o 1)
        printf("\n" AMARELO "[SISTEMA]" RESET " Pressione [" VERDE "ENTER" RESET "] para lancar os dados de combate...");
        do {
            tecla = getch();
        } while (tecla != 13);

        DadoJogador = (rand() % 6) + 1;
        printf("\n\nVALOR DADO DE %s = " VERDE "%i" RESET, Player->Nome, DadoJogador);

        DadoMonstro = (rand() % 6) + 1;
        printf("\nVALOR DADO DE %s = " VERMELHO "%i" RESET "\n", MonstroBatalha->Nome, DadoMonstro);

        sleep(2);
        if(DadoJogador > DadoMonstro)
        {
            Resultado = DadoJogador - DadoMonstro;
            Resultado = (Resultado * Player->Atk) - MonstroBatalha->Def;

            if(Resultado <= 0) Resultado = 1; // garante pelo menos um de dano.

            MonstroBatalha->Hp -= Resultado;
            if (MonstroBatalha->Hp < 0) MonstroBatalha->Hp = 0;
            system("cls");
            printf(CIANO "==================================================\n" RESET);
            printf("   HP %s = " VERMELHO "%i" RESET "  ||  HP INIMIGO (%s) = " VERMELHO "%i" RESET "\n", Player->Nome, Player->Hp, MonstroBatalha->Nome, MonstroBatalha->Hp);
            printf(CIANO "==================================================\n" RESET);
            printf("\n" VERDE "> VOCE CAUSOU %i DE DANO!" RESET "\n", Resultado);

        }
        else if(DadoJogador < DadoMonstro)
        {
            Resultado = DadoMonstro - DadoJogador;
            Resultado = (Resultado * MonstroBatalha->Atk) - Player->Def;

            if(Resultado <= 0) Resultado = 1; // garante pelo menos um de dano.

            Player->Hp -= Resultado;
            if (Player->Hp < 0) Player->Hp = 0;
            system("cls");
            printf(CIANO "==================================================\n" RESET);
            printf("   HP %s = " VERMELHO "%i" RESET "  ||  HP INIMIGO (%s) = " VERMELHO "%i" RESET "\n", Player->Nome, Player->Hp, MonstroBatalha->Nome, MonstroBatalha->Hp);
            printf(CIANO "==================================================\n" RESET);
            printf("\n" VERMELHO "> O INIMIGO CAUSOU %i DE DANO!" RESET "\n", Resultado);
        }
        else
        {
            printf("\n" AMARELO "> MISS!!" RESET "\n");
        }

        if(MonstroBatalha->Hp <= 0)
        {
            AtualizarProgresso(ListaMissoes, MonstroBatalha->Nome, Player);
            system("cls");
            printf(CIANO "==================================================\n" RESET);
            printf("   HP JOGADOR = " VERMELHO "%i" RESET "  ||  HP INIMIGO (%s) = " VERMELHO "%i" RESET "\n", Player->Hp, MonstroBatalha->Nome, MonstroBatalha->Hp);
            printf(CIANO "==================================================\n" RESET);
            printf(VERDE "==================================================\n" RESET);
            printf(VERDE "\n              PARABENS, VOCE VENCEU!            \n" RESET);
            printf(VERDE "==================================================\n" RESET); // Corrigida barra invertida extra
            printf("\n" AMARELO "+%d Moedas" RESET, MonstroBatalha->Moedas);
            printf("\n" VERDE "+%d Xp" RESET, MonstroBatalha->Xp);
            printf("\n" AZUL "-%d Energia" RESET, 20);
            printf("\n" AMARELO "-%d Fome" RESET "\n", 20);

            Player->Moedas += MonstroBatalha->Moedas;
            Player->Xp += MonstroBatalha->Xp;
            Player->Energia -= 20;
            Player->Fome -= 20;

            printf("\nPressione [" VERDE "ENTER" RESET "] para voltar ao menu...");
            do { tecla = getch(); } while (tecla != 13);
            return;
        }
        else if(Player->Hp <= 0)
        {
            system("cls");
            printf(VERMELHO "==================================================\n" RESET);
            printf(VERMELHO "\n                    GAME OVER                   \n" RESET);
            printf(VERMELHO "==================================================\n" RESET);
            printf("\nPressione [" VERDE "ENTER" RESET "] para fechar o jogo...");
            do { tecla = getch(); } while (tecla != 13);
            exit(0);
        }
        printf(" " VERDE "1" RESET " - LUTAR\n");
        printf(" " VERDE "2" RESET " - FUGIR (Tentativa %i)\n", tentativasFuga + 1);
        printf("\nEscolha: ");

        // CORRE��O: L� o caractere direto do teclado sem precisar de ENTER
        do {
            tecla = getch();
        } while (tecla != '1' && tecla != '2'); // S� aceita as teclas '1' ou '2'

        // Converte o caractere digitado ('1' ou '2') para o n�mero inteiro (1 ou 2)
        Escolha = tecla - '0';
    }
}


