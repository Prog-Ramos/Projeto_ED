#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

#include "Missoes.h"
#include "Menu.h"

// Insere uma nova missao no final da lista
Missao *InserirMissao(Missao *Inicio, int Codigo,
                      char Nome[], char Descricao[],
                      char MonstroAlvo[], int QuantidadeNecessaria,
                      int RecompensaXp, int Status)
{
    Missao *NovaMissao;
    Missao *aux;

    NovaMissao = malloc(sizeof(Missao));

    if(NovaMissao == NULL)
    {
        printf(VERMELHO "Erro ao alocar memoria!\n" RESET);
        return Inicio;
    }

    NovaMissao->Codigo = Codigo;

    strcpy(NovaMissao->Nome, Nome);
    strcpy(NovaMissao->Descricao, Descricao);
    strcpy(NovaMissao->MonstroAlvo, MonstroAlvo);

    NovaMissao->QuantidadeNecessaria = QuantidadeNecessaria;
    NovaMissao->Progresso = 0;

    NovaMissao->RecompensaXp = RecompensaXp;

    NovaMissao->Status = Status;
    NovaMissao->prox = NULL;

    if(Inicio == NULL)
    {
        Inicio = NovaMissao;
    }
    else
    {
        aux = Inicio;

        while(aux->prox != NULL)
        {
            aux = aux->prox;
        }

        aux->prox = NovaMissao;
    }

    return Inicio;
}

// Inicializa as missoes do jogo
Missao *InicializarMissoes()
{
    Missao *Inicio = NULL;

    Inicio = InserirMissao(Inicio, 1, "A Cacada a Manticora",
                           "Derrote 5 Manticoras.",
                           "Manticora", 5, 100, 1);

    Inicio = InserirMissao(Inicio, 2, "A Ameaca das Quimeras",
                           "Derrote 3 Quimeras.",
                           "Quimera", 3, 200, 0);

    Inicio = InserirMissao(Inicio, 3, "O Enigma da Esfinge",
                           "Derrote 1 Esfinge.",
                           "Esfinge", 1, 350, 0);

    return Inicio;
}

// Exibe todas as missoes cadastradas
void ExibirMissoes(Missao *Inicio)
{
    Missao *aux;

    aux = Inicio;

    system("cls");

    printf(CIANO "========================================\n" RESET);
    printf("                 " BRANCO "MISSOES" RESET "                \n");
    printf(CIANO "========================================\n" RESET);


    while(aux != NULL)
    {
        printf("\nCodigo: " VERDE "%d" RESET, aux->Codigo);
        printf("\nMissao: %s", aux->Nome);
        printf("\nDescricao: %s", aux->Descricao);

        printf("\nProgresso: " AMARELO "%d" RESET "/" CIANO "%d" RESET,
               aux->Progresso, aux->QuantidadeNecessaria);

        printf("\nRecompensa: " VERDE "%d XP" RESET, aux->RecompensaXp);

        if(aux->Status == 0)
        {
            printf("\nStatus: " VERMELHO "BLOQUEADA" RESET);
        }
        else if(aux->Status == 1)
        {
            printf("\nStatus: " AMARELO "DISPONIVEL" RESET);
        }
        else if(aux->Status == 2)
        {
            printf("\nStatus: " VERDE "CONCLUIDA" RESET);
        }

        printf("\n" CIANO "----------------------------------------" RESET);

        aux = aux->prox;
    }

    printf("\n\nPressione qualquer tecla para voltar...");
    getch();
}

// Atualiza o progresso quando um monstro e derrotado
void AtualizarProgresso(Missao *Inicio, char NomeMonstro[], Jogador *Player)
{
    Missao *aux;

    aux = Inicio;

    while(aux != NULL)
    {
        if(aux->Status == 1)
        {
            if(strcmp(aux->MonstroAlvo, NomeMonstro) == 0)
            {
                aux->Progresso++;

                printf("\n" CIANO "========================================" RESET);
                printf("\n       " BRANCO "PROGRESSO DA MISSAO" RESET);
                printf("\n" CIANO "========================================" RESET);
                printf("\nMissao: %s", aux->Nome);

                printf("\nProgresso: " AMARELO "%d" RESET "/" CIANO "%d" RESET,
                       aux->Progresso, aux->QuantidadeNecessaria);

                if(aux->Progresso >= aux->QuantidadeNecessaria)
                {
                    aux->Status = 2;

                    // Entrega a recompensa de XP
                    Player->Xp += aux->RecompensaXp;

                    printf("\n\n" VERDE "MISSAO CONCLUIDA!" RESET);
                    printf("\nVoce recebeu " VERDE "%d XP!" RESET, aux->RecompensaXp);

                    // Desbloqueia a proxima missao
                    if(aux->prox != NULL)
                    {
                        aux->prox->Status = 1;

                        printf("\n" AMARELO "Nova missao desbloqueada:" RESET " %s",
                               aux->prox->Nome);
                    }
                }
                printf("\n" CIANO "========================================\n" RESET);

                return;
            }
        }

        aux = aux->prox;
    }
}

