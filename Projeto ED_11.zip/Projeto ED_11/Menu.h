#ifndef MENU_H
#define MENU_H

#include "Monstros.h"
#include "Jogador.h"
#include "Inventario.h"
#include "Missoes.h"

//#ifndef MENU_H_INCLUDED
//#define MENU_H_INCLUDED

// --- DEFINIÇÕES DE CORES ANSI GLOBAIS ---
#define RESET    "\x1B[0m"
#define VERMELHO "\x1B[31m"
#define VERDE    "\x1B[32m"
#define AMARELO  "\x1B[33m"
#define AZUL     "\x1B[34m"
#define CIANO    "\x1B[36m"
#define BRANCO   "\x1B[37m"
#define BG_AZUL  "\x1B[44m"

// Declarações antecipadas: diz ao compilador que esses tipos existem
// Isso evita que o Menu.h quebre nas outras telas.
typedef struct Jogador;
typedef struct Itens;


void ExibirMenuPrincipal(Jogador *Player, BancoMonstros *NovoBancoMonstros,
                         Inventario *InventarioJogador, Missao *ListaMissoes);

void MenuExplorar(Jogador *Player, BancoMonstros *NovoBancoMonstros,
                  Inventario *InventarioJogador, Missao *ListaMissoes);
void MenuStatus(Jogador *Player);
void MenuTreinar(Jogador *Player);
void EncontraMonstro(Jogador *Player, BancoMonstros *NovoBancoMonstros,
                     Missao *ListaMissoes);
void Cidade(Jogador *Player, Inventario *InventarioJogador);
void Batalha(Jogador *Player, Monstros *MonstroBatalha, Missao *ListaMissoes);

//Funções adicionadas
void VerificarFome(Jogador *Player);
void AbrirInventario(Jogador *Player, Inventario *InventarioJogador);
void Loja(Jogador *Player, Inventario *InventarioJogador);
void Acampar(Jogador *Player, BancoMonstros *NovoBancoMonstros, Missao *ListaMissoes);

//Funções adicinadas
void EvoluirLevel(Jogador *Player);

#endif


