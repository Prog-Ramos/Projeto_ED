#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>

#include "Menu.h"
#include "Jogador.h"

// FUN��O QUE RETORNA UMA STRUCT COM TODOS OS ATRIBUTOS PARA O JOGADOR;
Jogador CriarJogador()
{
    Jogador NovoJogador; //NovoJogador � uma struct do tipo Jogador dentro da fun��o criarJogador.
    int OpcaoClasse = 0;

    printf(AMARELO"DIGITE O NOME DO PERSONAGEM: " RESET);
    // %49[^\n] limita a leitura a no m�ximo 49 caracteres para evitar bugs, reservando 1 para o \0
    scanf(" %49[^\n]", NovoJogador.Nome);

    // Limpa o caractere 'Enter' (\n) que sobrou da leitura do nome
    while (getchar() != '\n');

    // AQUI FAZEMOS A ENTRADA DA CLASSE E VERIFICA��O COM PROTE��O;
    system("cls");
    do {
        printf("\n" CIANO "================= ESCOLHA A CLASSE ================" RESET "\n");
        printf(" " VERDE "1" RESET " - Guerreiro \t(" VERMELHO "100 HP" RESET ", " AMARELO "5 ATK" RESET ", " AZUL "8 DEF" RESET ")\n");
        printf(" " VERDE "2" RESET " - Mago      \t(" VERMELHO "45 HP" RESET ", " AMARELO "15 ATK" RESET ", " AZUL "2 DEF" RESET ")\n");
        printf(" " VERDE "3" RESET " - Arqueiro  \t(" VERMELHO "70 HP" RESET ", " AMARELO "10 ATK" RESET ", " AZUL "4 DEF" RESET ")\n");
        printf("\nESCOLHA: ");


        // Se o scanf N�O retornar 1, significa que o usu�rio digitou letras ou espa�os
        if (scanf("%d", &OpcaoClasse) != 1) { //aqui ele verifica se o que foi digitado � um inteiro. Pois fazendo dessa forma � como se fosse uma compara��o, o scanf vai retornar 1 , pois se
            //o numero for um inteiro, ele retorna 1. Se ele n�o conseguiu armazenar em opcaoclasse ele retorna 0 e entra no if.

            system("cls");
            printf("\n" VERMELHO "[Erro] Entrada invalida! Digite apenas numeros." RESET "\n");


            while (getchar() != '\n'); //como a entrada foi invalida precisamos limpar o buffer do teclado com a entrada inv�lida
            OpcaoClasse = 0; // For�a uma op��o inv�lida para repetir o do-while

            continue; //pula para a verifica��o do while (OpcaoClasse < 1 || OpcaoClasse > 3). Como colocamos que OpcaoClasse=0 ele retorna no while.
        }

        // Limpa o 'Enter' ap�s o n�mero ser digitado com sucesso
        while (getchar() != '\n');

        if (OpcaoClasse < 1 || OpcaoClasse > 3) { //aqui verifica se o range do numero foi correto, pois ele pode digitar um inteiro e passar do primeiro IF, mas nesse caso precisavamos ver se foi de 1 a 3.
            system("cls");
            printf(VERMELHO "Opcao invalida! Tente novamente." RESET "\n");

        }


    } while (OpcaoClasse < 1 || OpcaoClasse > 3);

    NovoJogador.ClasseEscolhida = OpcaoClasse;

    // ATRIBUI��O PADR�O PARA TODAS AS CLASSES
    NovoJogador.Energia = 100;
    NovoJogador.Fome = 105; //come�a com 105 pois ao iniciar o jogo ja verificamos a fome do jogador.
    NovoJogador.Level = 1;
    NovoJogador.Xp = 0;
    NovoJogador.XpMax = 100;
    NovoJogador.Moedas = 100;
    NovoJogador.Atributo= 0;

    // ATRIBUI��O DA CLASSE NO PLAYER
    switch(NovoJogador.ClasseEscolhida)
    {
       case 1:
           NovoJogador.Hp = 100;
           NovoJogador.HpMax = 100;
           NovoJogador.Atk = 5;
           NovoJogador.Def = 8;
           strcpy(NovoJogador.Classe, "Guerreiro");
           break;
       case 2:
           NovoJogador.Hp = 45;
           NovoJogador.HpMax = 45;
           NovoJogador.Atk = 15;
           NovoJogador.Def = 2;
           strcpy(NovoJogador.Classe, "Mago");
           break;
       case 3:
           NovoJogador.Hp = 70;
           NovoJogador.HpMax = 70;
           NovoJogador.Atk = 10;
           NovoJogador.Def = 4;
           strcpy(NovoJogador.Classe, "Arqueiro");
           break;
    }

    system("cls");
    return NovoJogador;
}

