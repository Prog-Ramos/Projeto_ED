#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <string.h>
#include "Menu.h"

void Acampar(Jogador *Player, BancoMonstros *NovoBancoMonstros, Missao *ListaMissoes)
{
    system("cls");
    printf(CIANO "==================================================\n" RESET);
    printf("             " BRANCO "ACAMPAMENTO IMPROVISADO" RESET "              \n");
    printf(CIANO "==================================================\n" RESET);
    printf(AMARELO "[SISTEMA]" RESET " Preparando uma fogueira improvisada na selva...\n");
    printf(AMARELO "[SISTEMA]" RESET " Voce pega no sono tentando descansar...\n\n");
    printf(AMARELO "[SISTEMA]" RESET " Pressione [" VERDE "ENTER" RESET "] para passar a noite...");

    int tecla;
    do { tecla = getch(); } while (tecla != 13);

    // Chance de Emboscada (35% de chance de ser atacado enquanto dorme)
    int chanceEmboscada = rand() % 100;
    if (chanceEmboscada < 35)
    {
        printf("\n" VERMELHO "[!] VOCE FOI EMBOSCADO ENQUANTO DORMIA! [!]" RESET "\n");
        printf("\n" AMARELO "[SISTEMA]" RESET " Pressione [" VERDE "ENTER" RESET "] para continuar...");
        getch();
        do { tecla = getch(); } while (tecla != 13);

        EncontraMonstro(Player,NovoBancoMonstros,ListaMissoes);

        printf("\n" AMARELO "[SISTEMA]" RESET " Apos repelir o perigo, voce tenta cochilar o resto da noite...\n");
    }

    // Efeitos finais do acampamento
    Player->Hp += (Player->HpMax * 0.05); // Recupera só 5% de HP
    if (Player->Hp > Player->HpMax) Player->Hp = Player->HpMax;

    Player->Energia += 35; // Recupera 35% de energia
    if (Player->Energia > 100) Player->Energia = 100;

    Player->Fome -= 25; // Sente muita fome ao acordar ao relento

    printf("\n" CIANO "==================================================" RESET "\n");
    printf(VERDE "[+] HP Parcialmente Restaurado." RESET "\n");
    printf(VERDE "[+] Energia Parcialmente Restaurada." RESET "\n");
    printf(VERMELHO "[-] Fome aumentada significativamente!" RESET "\n");
    printf(CIANO "==================================================" RESET "\n");

    printf("\n" AMARELO "[SISTEMA]" RESET " Pressione qualquer tecla para retornar...");
    getch();
}
