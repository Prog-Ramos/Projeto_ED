#include <stdio.h>
#include <math.h>
#include <time.h>
#include <locale.h>
#include <stdlib.h>

#include "Monstros.h"
#include "Jogador.h"
#include "Menu.h"
#include "Inventario.h"
#include "Missoes.h"

int main()
{
    srand(time(NULL)); //Inicia a "semente" de randomização. Define um ponto de pardida que o rand() vai produzir

    setlocale(LC_ALL, "Portuguese"); //configurar a localidade do programa, no caso, portugues. Ai funciona os acentos

    printf(CIANO "================ " BRANCO "BEM-VINDO AO RPG" RESET CIANO " ================\n\n" RESET);

    Jogador Player = CriarJogador(); //Aqui criamos uma struct do tipo Jogador chamada Player. Ela recebe o retorno da função CriarJogador, que retorna uma struct do tipo Jogador.
    //Essa é a 1a chamada de função, que cria o nosso jogador Player. Esse Player será usado em todo o programa.

    Inventario InventarioJogador; //Aqui declaramos o inventario do Player.

    InicializaInventario(&InventarioJogador);
    /*Após essa chamada da função, nós ja temos a capacidade do inventario, quantos itens estão ocupando, e o espaço alocado para o ponteiro *itens*/

    AdicionarEquipamentosIniciais(&Player, &InventarioJogador);
    /*Essa função adiciona itens iniciais para cada classe. Passamos como argumentos o Player e Inventario*/

    BancoMonstros NovoBancoMonstros; //Criamos o banco de monstro

    InicializarMonstros(&NovoBancoMonstros);

    // Inicializando a lista de missoes
    Missao *ListaMissoes;

    ListaMissoes = InicializarMissoes();

    ExibirMenuPrincipal(&Player, &NovoBancoMonstros, &InventarioJogador, ListaMissoes);

    free(InventarioJogador.itens);

    return 0;
}
