
#include <stdio.h>
#include "BancoItens.h"

Item BancoItens[] = //Banco Itens � um vetor do tipo struct Item.
{
    // ==========================================
    // CATEGORIA 1 - ARMAS
    // ==========================================

    {1, "Espada de Ferro", 150, 100, 10, 0, 0, 0, 1},
    {2, "Espada de Aco", 300, 200, 18, 0, 0, 0, 1},
    {3, "Espada Longa", 450, 300, 25, 0, 0, 0, 1},
    {4, "Machado de Batalha", 525, 350, 30, 0, 0, 0, 1},
    {5, "Machado Pesado", 750, 500, 40, 0, 0, 0, 1},
    {6, "Adaga de Ferro", 90, 60, 7, 0, 0, 0, 1},
    {7, "Adaga Sombria", 375, 250, 22, 0, 0, 0, 1},
    {8, "Lanca de Madeira", 180, 120, 12, 0, 0, 0, 1},
    {9, "Lanca de Aco", 525, 350, 28, 0, 0, 0, 1},
    {10, "Espada Elfica", 1200, 800, 55, 0, 0, 0, 1},
    {11, "Cajado de Madeira", 120, 80, 8, 0, 0, 0, 1},
    {12, "Cajado Arcano", 450, 300, 25, 0, 0, 0, 1},
    {13, "Cajado Ancestral", 900, 600, 45, 0, 0, 0, 1},
    {14, "Orbe Magico", 600, 400, 35, 0, 0, 0, 1},
    {15, "Bastao das Sombras", 1500, 1000, 65, 0, 0, 0, 1},
    {31, "Arco de Madeira", 95, 65, 6, 0, 0, 0, 1},

    // ==========================================
    // CATEGORIA 2 - ARMADURAS
    // ==========================================

    {16, "Armadura de Pano", 90, 60, 0, 3, 0, 0, 2},
    {17, "Armadura de Couro", 180, 120, 0, 8, 0, 0, 2},
    {18, "Couraca de Ferro", 300, 200, 0, 15, 0, 0, 2},
    {19, "Armadura de Aco", 525, 350, 0, 23, 0, 0, 2},
    {20, "Armadura Reforcada", 750, 500, 0, 32, 0, 0, 2},
    {21, "Armadura Elfica", 1050, 700, 0, 40, 0, 0, 2},
    {22, "Armadura Sombria", 1350, 900, 0, 50, 0, 0, 2},
    {23, "Couraca do Rei", 1800, 1200, 0, 65, 0, 0, 2},
    {24, "Manto Arcano", 450, 300, 0, 18, 0, 0, 2},
    {25, "Tunica Ancestral", 900, 600, 0, 35, 0, 0, 2},
    {26, "Escudo de Madeira", 120, 80, 0, 6, 0, 0, 2},
    {27, "Escudo de Ferro", 300, 200, 0, 15, 0, 0, 2},
    {28, "Escudo de Aco", 600, 400, 0, 28, 0, 0, 2},
    {29, "Escudo Real", 1050, 700, 0, 45, 0, 0, 2},
    {30, "Escudo Lendario", 1800, 1200, 0, 70, 0, 0, 2},

    // ==========================================
    // CATEGORIA 3 - POCOES DE HP
    // ==========================================

    {32, "Pocao Pequena", 60, 40, 0, 0, 20, 0, 3},
    {33, "Pocao Media", 120, 80, 0, 0, 40, 0, 3},
    {34, "Pocao Grande", 225, 150, 0, 0, 70, 0, 3},
    {35, "Pocao Superior", 375, 250, 0, 0, 100, 0, 3},
    {36, "Elixir da Vida", 750, 500, 0, 0, 150, 0, 3},

    // ==========================================
    // CATEGORIA 4 - ALIMENTOS
    // ==========================================

    {37, "Pao", 15, 10, 0, 0, 0, 10, 4},
    {38, "Maca", 15, 10, 0, 0, 0, 8, 4},
    {39, "Carne Assada", 45, 30, 0, 0, 0, 25, 4},
    {40, "Racao", 30, 20, 0, 0, 0, 18, 4},
    {41, "Ensopado", 90, 60, 0, 0, 0, 40, 4},
    {42, "Banquete", 150, 100, 0, 0, 0, 60, 4}
};

// Retorna a quantidade de itens cadastrados
int QuantidadeItens()
{
    return sizeof(BancoItens) / sizeof(BancoItens[0]);
    //sizeof(BancoItens) nos da o tamanho total em bytes de todo o banco
    //sizeof(BancoItens[0]); nos da o tamanho de apenas 1 indice do banco
    //Dividindo um pelo outro, temos a quantidade de itens no banco, e podemos percorrer o for.

}

// Busca um item pelo codigo
int BuscarItemPorCodigo(int codigo, Item *itemEncontrado) //� do tipo int pois se retornar 1 , ele entra dentro do if de Buscar Int. Se retornar 0 � por que n�o achou o item.
{
    int i;

    for(i = 0; i < QuantidadeItens(); i++) //Chama fun��o QuantidadeItens. Fizemos assim pois se mudarmos algo, j� atualiza automaticamente o for.
    {
        if(BancoItens[i].Codigo == codigo) //Se achou o c�digo, o ponteiro *itemEncontrado atualiza com o item encontrado no banco. Ele ir� atualizar Arma/Armadura.
        {
            *itemEncontrado = BancoItens[i];
            return 1;
        }
    }

    return 0;
}

// Busca um item pela posicao no banco
int BuscarItemPorIndice(int indice, Item *itemEncontrado)
{
    if(indice < 0 || indice >= QuantidadeItens())
    {
        return 0;
    }

    *itemEncontrado = BancoItens[indice];

    return 1;
}

