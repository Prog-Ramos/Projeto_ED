#ifndef INVENTARIO_H
#define INVENTARIO_H
#include "Jogador.h"

typedef struct //declara��o da struct de ITENS. Ou seja , cada item ter� essas variaveis.
{
    int Codigo;
    char Nome[50];
    int PrecoCompra;
    int PrecoVenda;
    int Atk;
    int Def;
    int RecuperaHp; //itens que recuperam hp
    int RecuperaFome; //itens que recupar fome
    int Tipo; //categoriza��o dos itens para facilitar na loja

    //Armas , Armaduras , Po�oes de HP, Alimentos
} Item; //Alias da struct.


typedef struct
{
    Item *itens; //esse � o ponteiro que aponta para o primeiro indice do nosso vetor dinamico. Cada indice possui uma struct do tipo Item.

    int Capacidade; //capacidade total do iventario
    int Quantidade; //quantidade atual ocupada no invenario

} Inventario; //controla vetor de itens

//todas as fun��o que o header invenatrio.h carrega.

void InicializaInventario(Inventario *inv);

int AdicionaItem(Jogador *Player, Inventario *inv, Item novoItem);

int AumentaInventario(Inventario *inv, int espacos);

void ExibirInventario(Inventario *inv);

Item CriarArmaInicial(unsigned short int ClasseEscolhida);

Item CriarArmaduraInicial(unsigned short int ClasseEscolhida);

void AdicionarEquipamentosIniciais(Jogador *Player, Inventario *InventarioJogador);

Item CriarArmaInicial(unsigned short int ClasseEscolhida);

Item CriarArmaduraInicial(unsigned short int ClasseEscolhida);

int ComprarMochila(Jogador *Player, Inventario *inv);

int RemoveItem(Jogador *Player, Inventario *inv, int posicao);

void ConsumirItem(Jogador *Player, Inventario *inv);

#endif

