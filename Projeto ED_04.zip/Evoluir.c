#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <string.h>
#include <unistd.h>

#include "Menu.h"

void EvoluirLevel(Jogador *Player)
{
    if(Player->Xp>=Player->XpMax)
    {
        system("cls");
        printf("\n=========================================================");
        printf("\nPARABENS VOCE EVOLUIU DO LEVEL: %d PARA O LEVEL: %d\n",Player->Level,Player->Level+1);
        printf("=========================================================\n");
        Player->Level+=1; //Sobe de Level
        Player->HpMax*=1.05; //Aumenta 5% o HP
        Player->Hp=Player->HpMax;
        Player->Energia=100;
        Player->Fome=100;
        Player->Atributo+=1; //Adiciona 1 atributo
        Player->Xp=0; //Zera o Xp
        Player->XpMax*=1.3; //xp max passa a ser 30% a mais que o anterior
        sleep(3);

    }

}
