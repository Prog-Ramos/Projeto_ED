#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <unistd.h>

#include "Menu.h"

void Batalha(Jogador *Player, Monstros *MonstroBatalha)
{
    int DadoJogador;
    int DadoMonstro;
    int Resultado;
    int Escolha=1; //Como anteriormente o jogador escolheu Lutar, a escolha j� vem como 1.
    int Fuga;
    int DanoFuga;
    int tecla;
    int tentativasFuga = 0; // <-- NOVA VARI�VEL: Conta as tentativas de fuga nesta batalha

    while((Player->Hp > 0) && (MonstroBatalha->Hp > 0))
    {
        system("cls");

        printf("==================================================\n");
        printf("   HP %s = %i  ||  HP INIMIGO (%s) = %i\n",Player->Nome,Player->Hp, MonstroBatalha->Nome, MonstroBatalha->Hp);
        printf("==================================================\n");

        if(Escolha == 2)
        {

            Fuga = rand() % 100;

            // Condi��o modificada: Se a chance der certo OU se j� for a segunda (ou mais) tentativa
            if(Fuga < 20 || tentativasFuga >= 1)
            {
                printf("\n[Sucesso] Voce Fugiu!!\n");
                if(tentativasFuga >= 2) {
                    printf("(Fuga garantida por bravura!)\n");
                }
                printf("\nPressione [ENTER] para continuar...");
                do { tecla = getch(); } while (tecla != 13);
                return;
            }
            else
            {
                tentativasFuga++; // Incrementa o n�mero de tentativas
                // Calcula o dado do monstro para a penalidade de fuga
                DadoMonstro = (rand() % 6) + 1;
                DanoFuga = DadoMonstro * MonstroBatalha->Atk;
                Player->Hp -= DanoFuga;

                if(Player->Hp < 0)
                {
                    Player->Hp = 0;
                }
                system("cls");
                printf("==================================================\n");
                printf("   HP %s = %i  ||  HP INIMIGO (%s) = %i\n",Player->Nome,Player->Hp, MonstroBatalha->Nome, MonstroBatalha->Hp);
                printf("==================================================\n");
                printf("\nVOCE TENTA FUGIR MAS NAO CONSEGUE!\n");
                printf("\>O INIMIGO CAUSOU %i DE DANO NA SUA TENTATIVA DE FUGA!\n", DanoFuga);
                sleep(3);

                if(Player->Hp <= 0)
                {
                    system("cls");
                    printf("==================================================\n");
                    printf("\n                    GAME OVER                   \n");
                    printf("\n==================================================\n");
                    printf("\nPressione [ENTER] para fechar o jogo...");
                    do { tecla = getch(); } while (tecla != 13);
                    exit(0);
                }
                else
                {
                    printf(">\nA proxima tentativa de fuga sera 100%% garantida!\n"); // Aviso ao jogador
                }
                // Se o jogador morreu tentando fugir, verifica aqui
                system("pause");
            }
        }

        // 2. Se escolheu Lutar (Op��o 1)
        printf("\nPressione [ENTER] para lancar os dados de combate...");
        do {
            tecla = getch();
        } while (tecla != 13);

        DadoJogador = (rand() % 6) + 1;
        printf("\n\nVALOR DADO DE %s = %i", Player->Nome, DadoJogador);

        DadoMonstro = (rand() % 6) + 1;
        printf("\nVALOR DADO DE %s = %i\n", MonstroBatalha->Nome, DadoMonstro);

        sleep(2);
        if(DadoJogador > DadoMonstro)
        {
            Resultado = DadoJogador - DadoMonstro;
            Resultado = (Resultado * Player->Atk) - MonstroBatalha->Def;

            if(Resultado < 0) Resultado = 1; // garante pelo menos um de dano.

            MonstroBatalha->Hp -= Resultado;
            if (MonstroBatalha->Hp < 0) MonstroBatalha->Hp = 0;
            system("cls");
            printf("==================================================\n");
            printf("   HP %s = %i  ||  HP INIMIGO (%s) = %i\n",Player->Nome,Player->Hp, MonstroBatalha->Nome, MonstroBatalha->Hp);
            printf("==================================================\n");
            printf("\n> VOCE CAUSOU %i DE DANO!\n", Resultado);

        }
        else if(DadoJogador < DadoMonstro)
        {
            Resultado = DadoMonstro - DadoJogador;
            Resultado = (Resultado * MonstroBatalha->Atk) - Player->Def;

            if(Resultado <= 0) Resultado = 1; // garante pelo menos um de dano.

            Player->Hp -= Resultado;
            if (Player->Hp < 0) Player->Hp = 0;
            system("cls");
            printf("==================================================\n");
            printf("   HP %s = %i  ||  HP INIMIGO (%s) = %i\n",Player->Nome,Player->Hp, MonstroBatalha->Nome, MonstroBatalha->Hp);
            printf("==================================================\n");
            printf("\n> O INIMIGO CAUSOU %i DE DANO!\n", Resultado);
        }
        else
        {
            printf("\n> MISS!!\n");
        }

        if(MonstroBatalha->Hp <= 0)
        {
            system("cls");
            printf("==================================================\n");
            printf("   HP JOGADOR = %i  ||  HP INIMIGO (%s) = %i\n", Player->Hp, MonstroBatalha->Nome, MonstroBatalha->Hp);
            printf("==================================================\n");
            printf("==================================================\n");
            printf("\n              PARABENS, VOCE VENCEU!            \n");
            printf("\==================================================\n");
            printf("\n+%d Moedas", MonstroBatalha->Moedas);
            printf("\n+%d Xp", MonstroBatalha->Xp);
            printf("\n-%d Energia", 20);
            printf("\n-%d Fome\n", 20);

            Player->Moedas += MonstroBatalha->Moedas;
            Player->Xp += MonstroBatalha->Xp;
            Player->Energia -= 20;
            Player->Fome -= 20;

            printf("\nPressione [ENTER] para voltar ao menu...");
            do { tecla = getch(); } while (tecla != 13);
            return;
        }
        else if(Player->Hp <= 0)
        {
            system("cls");
            printf("==================================================\n");
            printf("\n                    GAME OVER                   \n");
            printf("==================================================\n");
            printf("\nPressione [ENTER] para fechar o jogo...");
            do { tecla = getch(); } while (tecla != 13);
            exit(0);
        }

        printf("1 - LUTAR\n");
        printf("2 - FUGIR (Tentativa %i)\n", tentativasFuga + 1);
        printf("\nEscolha: ");

        // CORRE��O: L� o caractere direto do teclado sem precisar de ENTER
        do {
            tecla = getch();
        } while (tecla != '1' && tecla != '2'); // S� aceita as teclas '1' ou '2'

        // Converte o caractere digitado ('1' ou '2') para o n�mero inteiro (1 ou 2)
        Escolha = tecla - '0';
    }
}


