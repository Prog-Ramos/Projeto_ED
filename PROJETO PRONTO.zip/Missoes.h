#ifndef MISSOES_H
#define MISSOES_H

#include "Jogador.h"

typedef struct Missao
{
    int Codigo;
    char Nome[100];
    char Descricao[200];

    char MonstroAlvo[50];
    int QuantidadeNecessaria;
    int Progresso;

    int RecompensaXp;

    int Status;

    struct Missao *prox;

} Missao;

Missao *InicializarMissoes();

Missao *InserirMissao(Missao *Inicio, int Codigo,
                      char Nome[], char Descricao[],
                      char MonstroAlvo[], int QuantidadeNecessaria,
                      int RecompensaXp, int Status);

void ExibirMissoes(Missao *Inicio);

void AtualizarProgresso(Missao *Inicio, char NomeMonstro[], Jogador *Player);

void LiberarMissoes(Missao *Inicio);

#endif
