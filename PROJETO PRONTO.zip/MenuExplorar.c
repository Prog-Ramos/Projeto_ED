#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <conio.h>

#include "Menu.h"

void MenuExplorar(Jogador *Player, BancoMonstros *NovoBancoMonstros,
                  Inventario *InventarioJogador, Missao *ListaMissoes)
{
    int opcao = 0;
    int tecla;
    do
    {
    system("cls");

    printf(CIANO "======================================================================================================\n" RESET);
    printf("   HP = " VERMELHO "%i/%i" RESET "  ||  LEVEL = " AMARELO "%i" RESET "  ||  XP = " VERDE "%i/%i" RESET "  ||  FOME = " AMARELO "%i%%" RESET "  ||  ENERGIA = " AZUL "%i%%" RESET "  ||  MOEDAS = " AMARELO "%i" RESET "\n", Player->Hp,Player->HpMax,Player->Level, Player->Xp, Player->XpMax,Player->Fome,Player->Energia,Player->Moedas);
    printf(CIANO "======================================================================================================\n" RESET);


    printf("\n" CIANO "================= EXPLORANDO =======================\n" RESET);
    printf(" " VERDE "1" RESET " - Procurar Monstros para Lutar\n");
    printf(" " VERDE "2" RESET " - Ir para uma cidade\n");
    printf(" " VERDE "3" RESET " - Voltar ao Menu Principal\n");
    printf(CIANO "==================================================\n" RESET);
    printf("ESCOLHA: ");

    tecla = getch();

    if(tecla < '1' || tecla > '3')
    {
        printf("\n" VERMELHO "Opcao invalida!" RESET "\n");
        system("pause");
    }

    }while(tecla < '1' || tecla > '3');

    opcao = tecla - '0';

    switch(opcao)
    {
        case 1:
            if(Player->Energia<20)
            {
                printf("\n" VERMELHO "[AVISO] Sua Energia e insuficiente! Energia atual: %d" RESET "\n",Player->Energia);
                system("pause");
            }
            else
            {
                VerificarFome(Player);
                printf("\n" AMARELO "[Sistema]" RESET " Entrando em combate...\n");
                EncontraMonstro(Player, NovoBancoMonstros, ListaMissoes);
            }
            break;
        case 2:
            if(Player->Energia<20)
            {
                printf("\n" VERMELHO "[AVISO] Sua Energia e insuficiente! Energia atual: %d" RESET "\n",Player->Energia);
                system("pause");
            }
            else
            {
                VerificarFome(Player);
                printf("\nCaminhando para cidade");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".");
                Cidade(Player, InventarioJogador);
            }
            break;
        case 3:
            {
            return;
            }

        default:
            printf("\n" VERMELHO "Opcao invalida! Tente novamente." RESET "\n");
            system("pause");
            break;
    }
}
