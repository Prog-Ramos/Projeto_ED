#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <unistd.h>

#include "Menu.h"
#include "Cores.h"

void EncontraMonstro(Jogador *Player, BancoMonstros *NovoBancoMonstros, Missao *ListaMissoes)
{
    system("cls");
    //SORTEIO
    int n = rand() % TOTAL_MONSTROS;
    int Escolha;
    int Fuga = rand()%100;
    int tecla;

    Escolha=0;

    //BACKUP DO BESTIARIO
    Monstros MonstroBatalha = NovoBancoMonstros->lista[n];

    while(MonstroBatalha.Level>Player->Level)
    {
        n = rand() % TOTAL_MONSTROS;
        MonstroBatalha = NovoBancoMonstros->lista[n];
    }
            // Painel Superior de Status (HUD) padronizado
    printf(CIANO "======================================================================================================\n" RESET);
    printf("   HP = " VERMELHO "%i/%i" RESET "  ||  LEVEL = " AMARELO "%i" RESET "  ||  XP = " VERDE "%i/%i" RESET "  ||  FOME = " AMARELO "%i%%" RESET "  ||  ENERGIA = " AZUL "%i%%" RESET "  ||  MOEDAS = " AMARELO "%i" RESET "\n",
            Player->Hp, Player->HpMax, Player->Level, Player->Xp,
            Player->XpMax, Player->Fome, Player->Energia, Player->Moedas);
    printf(CIANO "======================================================================================================\n" RESET);
    printf("\n" CIANO "========== "RESET VERMELHO "%s" RESET CIANO " - LEVEL = " RESET AMARELO "%d" RESET CIANO " ============\n", MonstroBatalha.Nome, MonstroBatalha.Level);
    printf(" " VERDE "1" RESET " - LUTAR\n");
    printf(" " VERDE "2" RESET " - FUGIR\n");
    printf("ESCOLHA: ");

    tecla=getch();

    Escolha=tecla-'0';

    while (tecla != '1' && tecla != '2')
    {
                // Painel Superior de Status (HUD) padronizado
        system("cls");
        printf(CIANO "======================================================================================================\n" RESET);
        printf("   HP = " VERMELHO "%i/%i" RESET "  ||  LEVEL = " AMARELO "%i" RESET "  ||  XP = " VERDE "%i/%i" RESET "  ||  FOME = " AMARELO "%i%%" RESET "  ||  ENERGIA = " AZUL "%i%%" RESET "  ||  MOEDAS = " AMARELO "%i" RESET "\n",
               Player->Hp, Player->HpMax, Player->Level, Player->Xp,
               Player->XpMax, Player->Fome, Player->Energia, Player->Moedas);
        printf(CIANO "======================================================================================================\n" RESET);

        printf("\n" CIANO " ========== " RESET VERMELHO "%s" RESET CIANO " - LEVEL = " RESET AMARELO "%d" RESET CIANO " ============!\n", MonstroBatalha.Nome, MonstroBatalha.Level);
        printf("\n" VERMELHO "[ALERTA] Escolha incorreta!" RESET "\n");
        printf(" " VERDE "1" RESET " - Lutar\n");
        printf(" " VERDE "2" RESET " - Fugir\n");
        printf("Escolha: ");

        tecla=getch();

        Escolha=tecla-'0';
    }
    if(Escolha==2)
        {
            if(Fuga<30)
            {
                printf("\n" VERDE "[Sucesso] Voce Fugiu!!" RESET "\n");
                system("pause");
            }
            else
            {
                printf("\n" VERMELHO "[Alerta] Voce tenta fugir mas nao consegue.. Prepare-se para Lutar" RESET "\n");
                system("pause");
                Batalha(Player, &MonstroBatalha, ListaMissoes);
            }
        }
    else
    {
        Batalha(Player, &MonstroBatalha, ListaMissoes);
    }

}
