#ifndef JOGADOR_H
#define JOGADOR_H



typedef struct {
    char Nome[50]; //limite de username
    char Classe[50]; //classes
    int Level;
    int Hp;
    int HpMax;
    int Xp;
    int XpMax;
    int Atk;
    int Def;
    int Moedas;
    int Energia;
    int Fome;
    int Atributo;
    unsigned short int ClasseEscolhida;
    unsigned short int BolsaComprada; //verifica se o jogador tem bolsa ou nao. 0 ele nao tem, 1 ele tem

} Jogador;

Jogador CriarJogador(); //Essa função vem carregada com o header Jogador.h

#endif
