#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>

#include "Menu.h"
#include "Jogador.h"

// FUN��O QUE RETORNA UMA STRUCT COM TODOS OS ATRIBUTOS PARA O JOGADOR;
Jogador CriarJogador()
{
    Jogador NovoJogador; //NovoJogador � uma struct do tipo Jogador dentro da fun��o criarJogador.
    int OpcaoClasse = 0;
    int tecla;

    printf(AMARELO"DIGITE O NOME DO PERSONAGEM: " RESET);
    // %49[^\n] limita a leitura a no m�ximo 49 caracteres para evitar bugs, reservando 1 para o \0
    scanf(" %49[^\n]", NovoJogador.Nome);

    printf("\nAtribuindo nome ao personagem");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".");

    // Limpa o caractere 'Enter' (\n) que sobrou da leitura do nome
    while (getchar() != '\n');

    // AQUI FAZEMOS A ENTRADA DA CLASSE E VERIFICA��O COM PROTE��O;
    system("cls");
    do {
        system("cls");
        printf("\n" CIANO "================= ESCOLHA A CLASSE ================" RESET "\n");
        printf(" " VERDE "1" RESET " - Guerreiro \t(" VERMELHO "100 HP" RESET ", " AMARELO "5 ATK" RESET ", " AZUL "8 DEF" RESET ")\n");
        printf(" " VERDE "2" RESET " - Mago      \t(" VERMELHO "45 HP" RESET ", " AMARELO "15 ATK" RESET ", " AZUL "2 DEF" RESET ")\n");
        printf(" " VERDE "3" RESET " - Arqueiro  \t(" VERMELHO "70 HP" RESET ", " AMARELO "10 ATK" RESET ", " AZUL "4 DEF" RESET ")\n");
        printf("\nESCOLHA: ");

        tecla = getch();

        if(tecla < '1' || tecla > '3')
        {
            printf("\n" VERMELHO "Opcao invalida!" RESET "\n");
            system("pause");
        }

        }while(tecla < '1' || tecla > '3');

        OpcaoClasse = tecla - '0';


    NovoJogador.ClasseEscolhida = OpcaoClasse;

    // ATRIBUI��O PADR�O PARA TODAS AS CLASSES
    NovoJogador.Energia = 100;
    NovoJogador.Fome = 100;
    NovoJogador.Level = 1;
    NovoJogador.Xp = 0;
    NovoJogador.XpMax = 300;
    NovoJogador.Moedas = 100;
    NovoJogador.Atributo= 0;
    NovoJogador.BolsaComprada = 0;

    // ATRIBUI��O DA CLASSE NO PLAYER
    switch(NovoJogador.ClasseEscolhida)
    {
       case 1:
           NovoJogador.Hp = 100;
           NovoJogador.HpMax = 100;
           NovoJogador.Atk = 5;
           NovoJogador.Def = 8;
           strcpy(NovoJogador.Classe, "Guerreiro");
           break;
       case 2:
           NovoJogador.Hp = 45;
           NovoJogador.HpMax = 45;
           NovoJogador.Atk = 15;
           NovoJogador.Def = 2;
           strcpy(NovoJogador.Classe, "Mago");
           break;
       case 3:
           NovoJogador.Hp = 70;
           NovoJogador.HpMax = 70;
           NovoJogador.Atk = 10;
           NovoJogador.Def = 4;
           strcpy(NovoJogador.Classe, "Arqueiro");
           break;
    }
    printf("\n");
    printf("\nCriando Jogador");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".");

    system("cls");
    return NovoJogador;
}

