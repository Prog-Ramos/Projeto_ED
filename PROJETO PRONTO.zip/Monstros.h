#ifndef MONSTROS_H
#define MONSTROS_H

#define TOTAL_MONSTROS 30

typedef struct{
    char Nome[50];
    short int Level;
    short int Hp;
    short int HpMax;
    short int Xp;
    short int Atk;
    short int Def;
    short int Moedas;
}Monstros;


typedef struct {
    Monstros lista[TOTAL_MONSTROS];
} BancoMonstros;


void InicializarMonstros(BancoMonstros *Banco);

#endif
