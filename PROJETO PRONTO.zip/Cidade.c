#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <unistd.h>

#include "Jogador.h"
#include "Menu.h"

void Cidade(Jogador *Player, Inventario *InventarioJogador)
{
    system("cls");

    VerificarFome(Player);

    int opcao;
    int tecla;

    // Divisória em Ciano, HP em Vermelho, Level/Fome/Moedas em Amarelo, XP em Verde e Energia em Azul
    printf(CIANO "======================================================================================================\n" RESET);
    printf("   HP = " VERMELHO "%i/%i" RESET "  ||  LEVEL = " AMARELO "%i" RESET "  ||  XP = " VERDE "%i/%i" RESET "  ||  FOME = " AMARELO "%i%%" RESET "  ||  ENERGIA = " AZUL "%i%%" RESET "  ||  MOEDAS = " AMARELO "%i" RESET "\n",
           Player->Hp, Player->HpMax, Player->Level, Player->Xp, Player->XpMax,
           Player->Fome, Player->Energia, Player->Moedas);
    printf(CIANO "======================================================================================================\n" RESET);

    printf("\n" AMARELO "[SISTEMA] Voce chegou na cidade, porem gastou energia!" RESET "\n");

    Player->Energia -= 10;

    if(Player->Energia < 0)
    {
        Player->Energia = 0;
    }

    system("pause");



    if(Player->Energia >= 10)
    {
        do
        {
            system("cls");

            printf(CIANO "======================================================================================================\n" RESET);
            printf("   HP = " VERMELHO "%i/%i" RESET "  ||  LEVEL = " AMARELO "%i" RESET "  ||  XP = " VERDE "%i/%i" RESET "  ||  FOME = " AMARELO "%i%%" RESET "  ||  ENERGIA = " AZUL "%i%%" RESET "  ||  MOEDAS = " AMARELO "%i" RESET "\n",
                   Player->Hp, Player->HpMax, Player->Level, Player->Xp, Player->XpMax,
                   Player->Fome, Player->Energia, Player->Moedas);
            printf(CIANO "======================================================================================================\n" RESET);

            // Caixa de boas-vindas colorida
            printf(CIANO "==================================================\n" RESET);
            printf("               " BRANCO BG_AZUL "BEM-VINDO A CIDADE" RESET "                 \n");
            printf(CIANO "==================================================\n" RESET);
            printf(" " VERDE "1" RESET " - Descansar na Estalagem (Cura Tudo) [" VERMELHO "-40 Moedas" RESET "]\n");
            printf(" " VERDE "2" RESET " - Comer na Taberna (Enche a Fome)    [" VERMELHO "-20 Moedas" RESET "]\n");
            printf(" " VERDE "3" RESET " - Visitar o Mercado (Loja de Itens)\n");
            printf(" " VERDE "4" RESET " - Abrir Inventario Pessoal\n");
            printf(" " VERDE "5" RESET " - Sair da Cidade (Voltar ao Menu)\n");
            printf(CIANO "==================================================\n" RESET);

            printf("Escolha uma opcao: ");

            tecla = getch();

            if(tecla < '1' || tecla > '5')
            {
                printf("\n" VERMELHO "Opcao invalida!" RESET "\n");
                system("pause");
                continue;
            }

            opcao = tecla - '0';

            switch(opcao)
            {
                case 1:
                    // --- OPÇÃO 1: ESTALAGEM ---
                    if (Player->Moedas >= 40) {
                        Player->Moedas -= 40;
                        Player->Hp = Player->HpMax;       // Cura completamente a vida
                        Player->Energia = 100;            // Descansar também recupera toda a energia
                        printf("\n" VERDE "[ESTALAGEM] Voce dormiu confortavelmente. HP e Energia totalmente restaurados!" RESET "\n");
                    } else {
                        printf("\n" VERMELHO "[ERRO] Moedas insuficientes! Voce precisa de 40 moedas." RESET "\n");
                    }
                    system("pause");
                    break;

                case 2:
                    // --- OPÇÃO 2: TABERNA ---
                    if (Player->Moedas >= 20) {
                        Player->Moedas -= 20;
                        Player->Fome = 100;              // Enche a barra de fome
                        printf("\n" VERDE "[TABERNA] Voce comeu uma refeicao farta. Fome saciada!" RESET "\n");
                    } else {
                        printf("\n" VERMELHO "[ERRO] Moedas insuficientes! Voce precisa de 20 moedas." RESET "\n");
                    }
                    system("pause");
                    break;

                case 3:
                    Loja(Player, InventarioJogador);
                    break;

                case 4:
                    AbrirInventario(Player, InventarioJogador);
                    break;

                case 5:
                    printf("\nSaindo da cidade");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".");
                    break;
            }

        } while(opcao != 5);
    }
    else
    {
        printf("\n" VERMELHO "Voce esta sem energia para ir ate a cidade! Faca um acampamento para se recuperar!" RESET "\n");
        system("pause");
    }
    VerificarFome(Player);

}


