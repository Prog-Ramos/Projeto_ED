#include <stdio.h>
#include <stdlib.h>
#include <conio.h>


#include "Menu.h"

void ExibirMenuPrincipal(Jogador *Player, BancoMonstros *NovoBancoMonstros,
                         Inventario *InventarioJogador, Missao *ListaMissoes)
{
    int opcao = 0;
    int tecla;

    do {
        EvoluirLevel(Player,InventarioJogador);

        system("cls");

        // Painel Superior de Status (HUD) padronizado
        printf(CIANO "======================================================================================================\n" RESET);
        printf("   HP = " VERMELHO "%i/%i" RESET "  ||  LEVEL = " AMARELO "%i" RESET "  ||  XP = " VERDE "%i/%i" RESET "  ||  FOME = " AMARELO "%i%%" RESET "  ||  ENERGIA = " AZUL "%i%%" RESET "  ||  MOEDAS = " AMARELO "%i" RESET "\n",
               Player->Hp, Player->HpMax, Player->Level, Player->Xp,
               Player->XpMax, Player->Fome, Player->Energia, Player->Moedas);
        printf(CIANO "======================================================================================================\n" RESET);
        // Estrutura do Menu Principal
        printf("\n" CIANO "================= MENU PRINCIPAL ================\n" RESET);
        printf(" " VERDE "1" RESET " - Explorar\n");
        printf(" " VERDE "2" RESET " - Status do Personagem\n");
        printf(" " VERDE "3" RESET " - Treinar\n");
        printf(" " VERDE "4" RESET " - Acampar\n");
        printf(" " VERDE "5" RESET " - Abrir Inventario Pessoal\n");
        printf(" " VERDE "6" RESET " - Missoes\n");
        printf(" " VERDE "7" RESET " - Sair do Jogo\n");
        printf(CIANO "==================================================\n" RESET);
        printf("ESCOLHA: ");

        tecla = getch();

        if(tecla < '1' || tecla > '7')
        {
            printf("\n" VERMELHO "Opcao invalida!" RESET "\n");
            system("pause");
            continue;
        }

        opcao = tecla - '0';

        switch (opcao) {
            case 1:
                VerificarFome(Player);
                MenuExplorar(Player, NovoBancoMonstros, InventarioJogador, ListaMissoes);
                break;

            case 2:
                MenuStatus(Player);
                break;

            case 3:
                VerificarFome(Player);
                MenuTreinar(Player);
                break;

            case 4:
                VerificarFome(Player);
                Acampar(Player, NovoBancoMonstros, ListaMissoes);
                break;

            case 5:
                AbrirInventario(Player, InventarioJogador);
                break;

            case 6:
                ExibirMissoes(ListaMissoes);
                break;

            case 7:
                printf("\n" AMARELO "Obrigado por jogar! Ate a proxima aventura." RESET "\n");
                break;

            default:
                printf("\n" VERMELHO "Opcao invalida!" RESET "\n");
                system("pause");
                break;
        }

    } while (opcao != 7);
}


