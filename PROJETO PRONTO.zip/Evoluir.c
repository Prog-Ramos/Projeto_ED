#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <string.h>
#include <unistd.h>

#include "Menu.h"

void EvoluirLevel(Jogador *Player,Inventario *InventarioJogador)
{
    if(Player->Xp>=Player->XpMax)
    {
        system("cls");
        printf("\n" VERDE "=========================================================" RESET);
        printf("\n" VERDE "PARABENS VOCE EVOLUIU DO LEVEL: " AMARELO "%d" VERDE " PARA O LEVEL: " AMARELO "%d" RESET "\n",Player->Level,Player->Level+1);
        printf(VERDE "=========================================================\n" RESET);
        Player->Level+=1; //Sobe de Level
        Player->HpMax*=1.05; //Aumenta 5% o HP
        Player->Hp=Player->HpMax;
        Player->Energia=100;
        Player->Fome=100;
        Player->Atributo+=1; //Adiciona 1 atributo

        AumentaInventario(InventarioJogador,1);//chamamos a funcao que aumenta inventario, passando como parametro o inventario do jogador e o aumento de 1 slot.

        Player->Xp=0; //Zera o Xp
        Player->XpMax*=1.55; //xp max passa a ser 55% a mais que o anterior
        system("pause");

    }


}
