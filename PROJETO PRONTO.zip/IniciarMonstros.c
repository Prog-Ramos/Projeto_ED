#include <stdio.h>
#include <string.h>


#include "Monstros.h"

void InicializarMonstros(BancoMonstros *Banco)
{
    // =========================
    // MONSTROS NIVEL 1
    // =========================

    strcpy(Banco->lista[0].Nome, "Rato Gigante");
    Banco->lista[0].Level = 1;
    Banco->lista[0].HpMax = 20;
    Banco->lista[0].Hp = 20;
    Banco->lista[0].Atk = 3;
    Banco->lista[0].Def = 1;
    Banco->lista[0].Xp = 25;
    Banco->lista[0].Moedas = 5;

    strcpy(Banco->lista[1].Nome, "Goblin");
    Banco->lista[1].Level = 1;
    Banco->lista[1].HpMax = 30;
    Banco->lista[1].Hp = 30;
    Banco->lista[1].Atk = 5;
    Banco->lista[1].Def = 2;
    Banco->lista[1].Xp = 30;
    Banco->lista[1].Moedas = 8;

    strcpy(Banco->lista[2].Nome, "Lobo Selvagem");
    Banco->lista[2].Level = 1;
    Banco->lista[2].HpMax = 35;
    Banco->lista[2].Hp = 35;
    Banco->lista[2].Atk = 6;
    Banco->lista[2].Def = 2;
    Banco->lista[2].Xp = 35;
    Banco->lista[2].Moedas = 8;

    strcpy(Banco->lista[3].Nome, "Javali Selvagem");
    Banco->lista[3].Level = 1;
    Banco->lista[3].HpMax = 40;
    Banco->lista[3].Hp = 40;
    Banco->lista[3].Atk = 5;
    Banco->lista[3].Def = 4;
    Banco->lista[3].Xp = 35;
    Banco->lista[3].Moedas = 10;

    strcpy(Banco->lista[4].Nome, "Aranha Gigante");
    Banco->lista[4].Level = 1;
    Banco->lista[4].HpMax = 25;
    Banco->lista[4].Hp = 25;
    Banco->lista[4].Atk = 6;
    Banco->lista[4].Def = 1;
    Banco->lista[4].Xp = 30;
    Banco->lista[4].Moedas = 7;

    strcpy(Banco->lista[5].Nome, "Bandido");
    Banco->lista[5].Level = 1;
    Banco->lista[5].HpMax = 45;
    Banco->lista[5].Hp = 45;
    Banco->lista[5].Atk = 7;
    Banco->lista[5].Def = 3;
    Banco->lista[5].Xp = 40;
    Banco->lista[5].Moedas = 12;


    // =========================
    // MONSTROS NIVEL 2
    // =========================

    strcpy(Banco->lista[6].Nome, "Esqueleto");
    Banco->lista[6].Level = 2;
    Banco->lista[6].HpMax = 45;
    Banco->lista[6].Hp = 45;
    Banco->lista[6].Atk = 9;
    Banco->lista[6].Def = 5;
    Banco->lista[6].Xp = 60;
    Banco->lista[6].Moedas = 12;

    strcpy(Banco->lista[7].Nome, "Morcego Gigante");
    Banco->lista[7].Level = 2;
    Banco->lista[7].HpMax = 40;
    Banco->lista[7].Hp = 40;
    Banco->lista[7].Atk = 11;
    Banco->lista[7].Def = 2;
    Banco->lista[7].Xp = 65;
    Banco->lista[7].Moedas = 13;

    strcpy(Banco->lista[8].Nome, "Cao de Guerra");
    Banco->lista[8].Level = 2;
    Banco->lista[8].HpMax = 55;
    Banco->lista[8].Hp = 55;
    Banco->lista[8].Atk = 10;
    Banco->lista[8].Def = 4;
    Banco->lista[8].Xp = 70;
    Banco->lista[8].Moedas = 15;

    strcpy(Banco->lista[9].Nome, "Goblin Saqueador");
    Banco->lista[9].Level = 2;
    Banco->lista[9].HpMax = 50;
    Banco->lista[9].Hp = 50;
    Banco->lista[9].Atk = 12;
    Banco->lista[9].Def = 3;
    Banco->lista[9].Xp = 75;
    Banco->lista[9].Moedas = 18;

    strcpy(Banco->lista[10].Nome, "Urso Selvagem");
    Banco->lista[10].Level = 2;
    Banco->lista[10].HpMax = 70;
    Banco->lista[10].Hp = 70;
    Banco->lista[10].Atk = 11;
    Banco->lista[10].Def = 6;
    Banco->lista[10].Xp = 80;
    Banco->lista[10].Moedas = 20;

    strcpy(Banco->lista[11].Nome, "Orc Jovem");
    Banco->lista[11].Level = 2;
    Banco->lista[11].HpMax = 65;
    Banco->lista[11].Hp = 65;
    Banco->lista[11].Atk = 13;
    Banco->lista[11].Def = 5;
    Banco->lista[11].Xp = 85;
    Banco->lista[11].Moedas = 22;


    // =========================
    // MONSTROS NIVEL 3
    // =========================

    strcpy(Banco->lista[12].Nome, "Zumbi");
    Banco->lista[12].Level = 3;
    Banco->lista[12].HpMax = 75;
    Banco->lista[12].Hp = 75;
    Banco->lista[12].Atk = 13;
    Banco->lista[12].Def = 6;
    Banco->lista[12].Xp = 100;
    Banco->lista[12].Moedas = 20;

    strcpy(Banco->lista[13].Nome, "Aranha Venenosa");
    Banco->lista[13].Level = 3;
    Banco->lista[13].HpMax = 65;
    Banco->lista[13].Hp = 65;
    Banco->lista[13].Atk = 16;
    Banco->lista[13].Def = 5;
    Banco->lista[13].Xp = 110;
    Banco->lista[13].Moedas = 22;

    strcpy(Banco->lista[14].Nome, "Orc Guerreiro");
    Banco->lista[14].Level = 3;
    Banco->lista[14].HpMax = 90;
    Banco->lista[14].Hp = 90;
    Banco->lista[14].Atk = 17;
    Banco->lista[14].Def = 8;
    Banco->lista[14].Xp = 120;
    Banco->lista[14].Moedas = 25;

    strcpy(Banco->lista[15].Nome, "Lobo Alfa");
    Banco->lista[15].Level = 3;
    Banco->lista[15].HpMax = 85;
    Banco->lista[15].Hp = 85;
    Banco->lista[15].Atk = 18;
    Banco->lista[15].Def = 7;
    Banco->lista[15].Xp = 125;
    Banco->lista[15].Moedas = 28;

    strcpy(Banco->lista[16].Nome, "Ogro");
    Banco->lista[16].Level = 3;
    Banco->lista[16].HpMax = 120;
    Banco->lista[16].Hp = 120;
    Banco->lista[16].Atk = 19;
    Banco->lista[16].Def = 10;
    Banco->lista[16].Xp = 140;
    Banco->lista[16].Moedas = 30;

    strcpy(Banco->lista[17].Nome, "Cavaleiro Renegado");
    Banco->lista[17].Level = 3;
    Banco->lista[17].HpMax = 100;
    Banco->lista[17].Hp = 100;
    Banco->lista[17].Atk = 20;
    Banco->lista[17].Def = 12;
    Banco->lista[17].Xp = 150;
    Banco->lista[17].Moedas = 35;


    // =========================
    // MONSTROS NIVEL 4
    // =========================

    strcpy(Banco->lista[18].Nome, "Troll");
    Banco->lista[18].Level = 4;
    Banco->lista[18].HpMax = 140;
    Banco->lista[18].Hp = 140;
    Banco->lista[18].Atk = 22;
    Banco->lista[18].Def = 12;
    Banco->lista[18].Xp = 170;
    Banco->lista[18].Moedas = 35;

    strcpy(Banco->lista[19].Nome, "Assassino");
    Banco->lista[19].Level = 4;
    Banco->lista[19].HpMax = 100;
    Banco->lista[19].Hp = 100;
    Banco->lista[19].Atk = 27;
    Banco->lista[19].Def = 8;
    Banco->lista[19].Xp = 180;
    Banco->lista[19].Moedas = 40;

    strcpy(Banco->lista[20].Nome, "Necromante");
    Banco->lista[20].Level = 4;
    Banco->lista[20].HpMax = 110;
    Banco->lista[20].Hp = 110;
    Banco->lista[20].Atk = 25;
    Banco->lista[20].Def = 10;
    Banco->lista[20].Xp = 190;
    Banco->lista[20].Moedas = 42;

    strcpy(Banco->lista[21].Nome, "Urso das Cavernas");
    Banco->lista[21].Level = 4;
    Banco->lista[21].HpMax = 160;
    Banco->lista[21].Hp = 160;
    Banco->lista[21].Atk = 24;
    Banco->lista[21].Def = 14;
    Banco->lista[21].Xp = 200;
    Banco->lista[21].Moedas = 45;

    strcpy(Banco->lista[22].Nome, "Chefe Orc");
    Banco->lista[22].Level = 4;
    Banco->lista[22].HpMax = 170;
    Banco->lista[22].Hp = 170;
    Banco->lista[22].Atk = 28;
    Banco->lista[22].Def = 15;
    Banco->lista[22].Xp = 220;
    Banco->lista[22].Moedas = 50;

    strcpy(Banco->lista[23].Nome, "Cavaleiro Negro");
    Banco->lista[23].Level = 4;
    Banco->lista[23].HpMax = 150;
    Banco->lista[23].Hp = 150;
    Banco->lista[23].Atk = 30;
    Banco->lista[23].Def = 18;
    Banco->lista[23].Xp = 230;
    Banco->lista[23].Moedas = 55;


    // =========================
    // MONSTROS NIVEL 5
    // =========================

    strcpy(Banco->lista[24].Nome, "Dragao Jovem");
    Banco->lista[24].Level = 5;
    Banco->lista[24].HpMax = 200;
    Banco->lista[24].Hp = 200;
    Banco->lista[24].Atk = 35;
    Banco->lista[24].Def = 20;
    Banco->lista[24].Xp = 280;
    Banco->lista[24].Moedas = 70;

    strcpy(Banco->lista[25].Nome, "Gigante das Montanhas");
    Banco->lista[25].Level = 5;
    Banco->lista[25].HpMax = 240;
    Banco->lista[25].Hp = 240;
    Banco->lista[25].Atk = 32;
    Banco->lista[25].Def = 22;
    Banco->lista[25].Xp = 300;
    Banco->lista[25].Moedas = 75;

    strcpy(Banco->lista[26].Nome, "Troll Anciao");
    Banco->lista[26].Level = 5;
    Banco->lista[26].HpMax = 220;
    Banco->lista[26].Hp = 220;
    Banco->lista[26].Atk = 38;
    Banco->lista[26].Def = 25;
    Banco->lista[26].Xp = 320;
    Banco->lista[26].Moedas = 80;

    strcpy(Banco->lista[27].Nome, "Demonio Menor");
    Banco->lista[27].Level = 5;
    Banco->lista[27].HpMax = 190;
    Banco->lista[27].Hp = 190;
    Banco->lista[27].Atk = 40;
    Banco->lista[27].Def = 18;
    Banco->lista[27].Xp = 330;
    Banco->lista[27].Moedas = 85;

    strcpy(Banco->lista[28].Nome, "Senhor dos Orcs");
    Banco->lista[28].Level = 5;
    Banco->lista[28].HpMax = 250;
    Banco->lista[28].Hp = 250;
    Banco->lista[28].Atk = 42;
    Banco->lista[28].Def = 25;
    Banco->lista[28].Xp = 350;
    Banco->lista[28].Moedas = 100;

    strcpy(Banco->lista[29].Nome, "Guardiao das Trevas");
    Banco->lista[29].Level = 5;
    Banco->lista[29].HpMax = 280;
    Banco->lista[29].Hp = 280;
    Banco->lista[29].Atk = 40;
    Banco->lista[29].Def = 30;
    Banco->lista[29].Xp = 400;
    Banco->lista[29].Moedas = 120;
}
