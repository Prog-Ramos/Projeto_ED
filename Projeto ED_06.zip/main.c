#include <stdio.h>
#include <math.h>
#include <time.h> //para usar o srand
#include <locale.h>
#include <stdlib.h>

#include "Monstros.h"
#include "Jogador.h"
#include "Menu.h"
#include "Inventario.h"

int main()
{

    srand(time(NULL)); //time Null: retorna horario de computador em segundos contado a partide de 1 de janeiro de 1970. e srand define a semente que o algoritmo usa de aleatoriedade

    setlocale(LC_ALL, "Portuguese"); //configurar o programa para o idioma portugues

    printf("================ BEM-VINDO AO RPG ================\n\n");

    Jogador Player = CriarJogador(); //jogador � uma struct.

    Inventario InventarioJogador; //criando invetario do jogador

    InicializaInventario(&InventarioJogador); //inicializando o invent�rio

    AdicionarEquipamentosIniciais(&Player, &InventarioJogador);

    BancoMonstros NovoBancoMonstros;

    InicializarMonstros(&NovoBancoMonstros);

    ExibirMenuPrincipal(&Player, &NovoBancoMonstros, &InventarioJogador);

    free(InventarioJogador.itens); //so executa quando o jogo termina.

    return 0;
}
