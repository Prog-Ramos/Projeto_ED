#ifndef JOGADOR_H
#define JOGADOR_H

//mudar unsigned..

typedef struct {
    char Nome[50];
    char Classe[50];
    unsigned short int Level;
    short int Hp;
    short int HpMax;      //JOGADOR 50/100
    unsigned short int Xp;
    unsigned short int XpMax; //Adicionado XpMax
    unsigned short int Atk;
    unsigned short int Def;
    short int Moedas;
    short int Energia;
    unsigned short int ClasseEscolhida;
    unsigned short int BolsaComprada; //verifica se o jogador tem bolsa ou nao. 0 ele nao tem, 1 ele tem
    short int Fome;
    short int Atributo;
    // Novas variáveis para jogador.
    unsigned short int PocaoHp;
    unsigned short int Racao;

} Jogador;

Jogador CriarJogador();

#endif
