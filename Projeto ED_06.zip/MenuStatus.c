#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <unistd.h>

#include "Menu.h"


void MenuStatus(Jogador *Player)
{
    int tecla;

    if(Player->Atributo>0)
    {
        system("cls");
        printf("==================================================\n");
        printf("                FICHA DO PERSONAGEM               \n");
        printf("==================================================\n");
        printf("Nome: %s\n", Player->Nome);
        printf("Classe: %s\n", Player->Classe);
        printf("Level: %d | XP: %d/%d\n",Player->Level,Player->Xp,Player->XpMax);
        printf("HP: %d/%d\n", Player->Hp, Player->HpMax);
        printf("Ataque: %d | Defesa: %d\n", Player->Atk, Player->Def);
        printf("Energia: %d%% | Fome: %d%%\n", Player->Energia, Player->Fome);
        printf("Moedas: %d GP\n", Player->Moedas);
        printf("Atributos: %d\n",Player->Atributo);
        printf("==================================================\n");

        printf("\nVoce possui %d atributos, deseja usar ?\n",Player->Atributo);
        printf("1 - Usar Atributo\n");
        printf("2 - Voltar para menu\n");
        printf("\nESCOLHA: ");

        tecla=getch();

        while (tecla != '1' && tecla != '2')
        {
            system("cls");
            printf("==================================================\n");
            printf("                FICHA DO PERSONAGEM               \n");
            printf("==================================================\n");
            printf("Nome: %s\n", Player->Nome);
            printf("Classe: %s\n", Player->Classe);
            printf("Level: %d | XP: %d/%d\n",Player->Level, Player->Xp,Player->XpMax);
            printf("HP: %d/%d\n", Player->Hp, Player->HpMax);
            printf("Ataque: %d | Defesa: %d\n", Player->Atk, Player->Def);
            printf("Energia: %d%% | Fome: %d%%\n", Player->Energia, Player->Fome);
            printf("Moedas: %d GP\n", Player->Moedas);
            printf("Atributos: %d\n",Player->Atributo);
            printf("==================================================\n");

            printf("\n[ALERTA]Escolha incorreta!\n");
            printf("1 - Usar Atributo\n");
            printf("2 - Voltar para menu\n");
            printf("\nESCOLHA: ");

            tecla=getch();


        }
        if(tecla=='1')
        {
            while(Player->Atributo>0)
            {
                printf("\nEscolha onde aplicar o seu atributo\n");
                printf("\n1 - ATAQUE");
                printf("\n2 - DEFESA");
                printf("\nESCOLHA: ");

                tecla=getch();

                while (tecla != '1' && tecla != '2')
                {
                    system("cls");
                    printf("==================================================\n");
                    printf("                FICHA DO PERSONAGEM               \n");
                    printf("==================================================\n");
                    printf("Nome: %s\n", Player->Nome);
                    printf("Classe: %s\n", Player->Classe);
                    printf("Level: %d | XP: %d/%d\n",Player->Level, Player->Xp,Player->XpMax);
                    printf("HP: %d/%d\n", Player->Hp, Player->HpMax);
                    printf("Ataque: %d | Defesa: %d\n", Player->Atk, Player->Def);
                    printf("Energia: %d%% | Fome: %d%%\n", Player->Energia, Player->Fome);
                    printf("Moedas: %d GP\n", Player->Moedas);
                    printf("Atributos: %d\n",Player->Atributo);
                    printf("==================================================\n");


                    printf("\n[ALERTA]Escolha incorreta!\n");
                    printf("\n1 - ATAQUE");
                    printf("\n2 - DEFESA");
                    printf("\nESCOLHA: ");

                    tecla=getch();


                }
                switch(tecla)
                {
                    case '1':
                        {
                            Player->Atk+=1;
                            Player->Atributo-=1;
                            system("cls");
                            printf("==================================================\n");
                            printf("                FICHA DO PERSONAGEM               \n");
                            printf("==================================================\n");
                            printf("Nome: %s\n", Player->Nome);
                            printf("Classe: %s\n", Player->Classe);
                            printf("Level: %d | XP: %d/%d\n",Player->Level, Player->Xp,Player->XpMax);
                            printf("HP: %d/%d\n", Player->Hp, Player->HpMax);
                            printf("Ataque: %d | Defesa: %d\n", Player->Atk, Player->Def);
                            printf("Energia: %d%% | Fome: %d%%\n", Player->Energia, Player->Fome);
                            printf("Moedas: %d GP\n", Player->Moedas);
                            printf("Atributos: %d\n",Player->Atributo);
                            printf("==================================================\n");
                            break;
                        }
                    case '2':
                        {
                            Player->Def+=1;
                            Player->Atributo-=1;
                            system("cls");
                            printf("==================================================\n");
                            printf("                FICHA DO PERSONAGEM               \n");
                            printf("==================================================\n");
                            printf("Nome: %s\n", Player->Nome);
                            printf("Classe: %s\n", Player->Classe);
                            printf("Level: %d | XP: %d/%d\n",Player->Level, Player->Xp,Player->XpMax);
                            printf("HP: %d/%d\n", Player->Hp, Player->HpMax);
                            printf("Ataque: %d | Defesa: %d\n", Player->Atk, Player->Def);
                            printf("Energia: %d%% | Fome: %d%%\n", Player->Energia, Player->Fome);
                            printf("Moedas: %d GP\n", Player->Moedas);
                            printf("Atributos: %d\n",Player->Atributo);
                            printf("==================================================\n");
                            break;
                        }

                }

                if(Player->Atributo==0)
                {
                    break;
                }
                else
                {
                    printf("\nVoce ainda possui %d atributos, deseja continuar usando ? ",Player->Atributo);
                    printf("\n1 - SIM");
                    printf("\n2 - VOLTAR AO MENU");
                    printf("\nESCOLHA: ");
                    tecla=getch();

                    while (tecla != '1' && tecla != '2')
                    {
                        printf("\n[ALERTA]Escolha incorreta!\n");
                        printf("\n1 - SIM");
                        printf("\n2 - VOLTAR AO MENU");
                        printf("\nESCOLHA: ");

                        tecla=getch();

                    }

                    if(tecla=='2')
                    {
                        return;
                    }

                }

            }

        }

    }
    if(Player->Atributo==0)
    {
        system("cls");
        printf("==================================================\n");
        printf("                FICHA DO PERSONAGEM               \n");
        printf("==================================================\n");
        printf("Nome: %s\n", Player->Nome);
        printf("Classe: %s\n", Player->Classe);
        printf("Level: %d | XP: %d/%d\n",Player->Level, Player->Xp,Player->XpMax);
        printf("HP: %d/%d\n", Player->Hp, Player->HpMax);
        printf("Ataque: %d | Defesa: %d\n", Player->Atk, Player->Def);
        printf("Energia: %d%% | Fome: %d%%\n", Player->Energia, Player->Fome);
        printf("Moedas: %d GP\n", Player->Moedas);
        printf("Atributos: %d\n",Player->Atributo);
        printf("==================================================\n");

        printf("\nVoce nao possui nenhum atributo ! Evolua de nivel para conseguir atributos\n");
        system("pause");
    }





}


