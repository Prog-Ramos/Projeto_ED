#include <stdio.h>
#include <stdlib.h>
#include "Inventario.h"

void InicializaInventario(Inventario *inv)
{
    inv->Capacidade = 4; //capacidade inicial do personagem
    inv->Quantidade = 0; //nenhum item armazenado at� o momento

    inv->itens = malloc(inv->Capacidade * sizeof(Item)); //reservamos espa�o na mem�ria para 4 itens. O tipo que deve ser usado � o Item.

    if (inv->itens == NULL)
    {
        printf("Erro ao alocar memoria para o inventario!\n");
        exit(1);
    }
}

int AdicionaItem(Inventario *inv, Item novoItem) //aqui estamos passando novamente o ponteiro *inv do tipo Inventario, e criando uma nova struc
{
    if (inv->Quantidade >= inv->Capacidade)
    {
        printf("Inventario cheio!\n");
        return 0;
    }

    inv->itens[inv->Quantidade] = novoItem;

    inv->Quantidade++;

    return 1; // 1 adicionou o item. 0 n�o adicionou

}

int AumentaInventario(Inventario *inv, int espacos)
{
    int NovaCapacidade;
    Item *aux;

    NovaCapacidade = inv->Capacidade + espacos;

    aux = realloc(inv->itens, NovaCapacidade * sizeof(Item));

    if (aux == NULL)
    {
        printf("Erro ao aumentar o inventario!\n");
        return 0;
    }

    inv->itens = aux;
    inv->Capacidade = NovaCapacidade;

    return 1;
}

void ExibirInventario(Inventario *inv)
{
    int i;

    printf("\n===== INVENTARIO =====\n");

    for (i = 0; i < inv->Quantidade; i++)
    {
        printf("%d - %s\n", i + 1, inv->itens[i].Nome);
    }

    printf("\nEspacos ocupados: %d", inv->Quantidade);
    printf("\nCapacidade: %d\n", inv->Capacidade);
}
