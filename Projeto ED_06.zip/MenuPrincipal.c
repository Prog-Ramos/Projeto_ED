#include <stdio.h>
#include <stdlib.h>

#include "Menu.h"

void ExibirMenuPrincipal(Jogador *Player, BancoMonstros *NovoBancoMonstros, Inventario *InventarioJogador)
{

    int opcao = 0;

    do {
        EvoluirLevel(Player);
        VerificarFome(Player);
        system("cls");
        printf("======================================================================================================\n");
        printf("   HP = %i/%i  ||  LEVEL = %i  ||  XP = %i/%i  ||  FOME = %i%%  ||  ENERGIA = %i%%  ||  MOEDAS = %i\n", Player->Hp,Player->HpMax,Player->Level, Player->Xp, Player->XpMax,Player->Fome,Player->Energia,Player->Moedas);
        printf("======================================================================================================\n");
        printf("\n================= MENU PRINCIPAL ================\n");
        printf("1 - Explorar\n");
        printf("2 - Status do Personagem\n");
        printf("3 - Treinar\n");
        printf("4 - Acampar\n");
        printf("5 - Abrir Inventario Pessoal\n");
        printf("6 - Sair do Jogo\n");
        printf("==================================================\n");
        printf("ESCOLHA: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                MenuExplorar(Player, NovoBancoMonstros, InventarioJogador);
                break;
            case 2:
                MenuStatus(Player);
                break;
            case 3:
                MenuTreinar(Player);
                break;
            case 4:
                Acampar(Player, NovoBancoMonstros);
                break;
            case 5:
                AbrirInventario(Player, InventarioJogador);
                break;
            case 6:
                printf("\nObrigado por jogar! At� a pr�xima aventura.\n");
                break;
            default:
                printf("\nOp��o inv�lida! Tente novamente.\n");
                break;
        }
    } while (opcao != 6);
}


