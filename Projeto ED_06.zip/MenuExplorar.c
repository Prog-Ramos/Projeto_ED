#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "Menu.h"
void MenuExplorar(Jogador *Player, BancoMonstros *NovoBancoMonstros, Inventario *InventarioJogador)
{
    VerificarFome(Player);
    system("cls");

    printf("======================================================================================================\n");
    printf("   HP = %i/%i  ||  LEVEL = %i  ||  XP = %i/%i  ||  FOME = %i%%  ||  ENERGIA = %i%%  ||  MOEDAS = %i\n", Player->Hp,Player->HpMax,Player->Level, Player->Xp, Player->XpMax,Player->Fome,Player->Energia,Player->Moedas);
    printf("======================================================================================================\n");

    int Escolha = 0;
    printf("\n================= EXPLORA��O =======================\n");
    printf("1 - Procurar Monstros para Lutar\n");
    printf("2 - Ir para uma cidade\n");
    printf("3 - Voltar ao Menu Principal\n");
    printf("==================================================\n");
    printf("Escolha: ");
    scanf("%d", &Escolha);

    switch(Escolha)
    {
        case 1:
            if(Player->Energia<20)
            {
                printf("\n[AVISO]Sua Energia e insuficiente ! Energia atual: %d",Player->Energia);
            }
            else
            {
                printf("\n[Sistema] Entrando em combate...\n");
                EncontraMonstro(Player,NovoBancoMonstros);
            }
            break;
        case 2:
            if(Player->Energia<20)
            {
                printf("\n[AVISO]Sua Energia e insuficiente ! Energia atual: %d",Player->Energia);
            }
            else
            {
                Cidade(Player, InventarioJogador);;
            }
            break;
        default:
            break;
    }
}
