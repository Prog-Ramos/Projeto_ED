#include <stdio.h>
#include <string.h>
#include "Inventario.h"
#include "Jogador.h"

Item CriarArmaInicial(unsigned short int ClasseEscolhida)
{
    Item Arma;

    switch(ClasseEscolhida)
    {
        case 1:
            Arma.Codigo = 1;
            strcpy(Arma.Nome, "Espada");
            Arma.Preco = 0;
            Arma.Atk = 10;
            Arma.Def = 0;
            break;

        case 2:
            Arma.Codigo = 3;
            strcpy(Arma.Nome, "Cajado");
            Arma.Preco = 0;
            Arma.Atk = 15;
            Arma.Def = 0;
            break;

        case 3:
            Arma.Codigo = 5;
            strcpy(Arma.Nome, "Arco");
            Arma.Preco = 0;
            Arma.Atk = 12;
            Arma.Def = 0;
            break;
    }

    return Arma;
}

Item CriarArmaduraInicial(unsigned short int ClasseEscolhida)
{
    Item Armadura;

    switch(ClasseEscolhida)
    {
        case 1:
            Armadura.Codigo = 2;
            strcpy(Armadura.Nome, "Couraca");
            Armadura.Preco = 0;
            Armadura.Atk = 0;
            Armadura.Def = 8;
            break;

        case 2:
            Armadura.Codigo = 4;
            strcpy(Armadura.Nome, "Armadura de Pano");
            Armadura.Preco = 0;
            Armadura.Atk = 0;
            Armadura.Def = 2;
            break;

        case 3:
            Armadura.Codigo = 6;
            strcpy(Armadura.Nome, "Armadura de Couro");
            Armadura.Preco = 0;
            Armadura.Atk = 0;
            Armadura.Def = 4;
            break;
    }

    return Armadura;
}

void AdicionarEquipamentosIniciais(Jogador *Player, Inventario *InventarioJogador)
{
    Item Arma;
    Item Armadura;

    Arma = CriarArmaInicial(Player->ClasseEscolhida);
    Armadura = CriarArmaduraInicial(Player->ClasseEscolhida);

    AdicionaItem(InventarioJogador, Arma);
    AdicionaItem(InventarioJogador, Armadura);
}
