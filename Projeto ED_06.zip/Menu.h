#ifndef MENU_H
#define MENU_H

#include "Monstros.h"
#include "Jogador.h"
#include "Inventario.h"


void ExibirMenuPrincipal(Jogador *Player, BancoMonstros *NovoBancoMonstros, Inventario *InventarioJogador);

void MenuExplorar(Jogador *Player, BancoMonstros *NovoBancoMonstros, Inventario *InventarioJogador);
void MenuStatus(Jogador *Player);
void MenuTreinar(Jogador *Player);
void EncontraMonstro(Jogador *Player, BancoMonstros *NovoBancoMonstros);
void Cidade(Jogador *Player, Inventario *InventarioJogador);
void Batalha(Jogador *Player, Monstros *MonstroBatalha);

//Funções adicionadas
void VerificarFome(Jogador *Player);
void AbrirInventario(Jogador *Player, Inventario *InventarioJogador);
void Loja(Jogador *Player);
void Acampar(Jogador *Player,BancoMonstros *NovoBancoMonstros);

//Funções adicinadas
void EvoluirLevel(Jogador *Player);

#endif


