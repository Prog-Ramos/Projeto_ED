#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <unistd.h>

#include "Menu.h"

void Cidade(Jogador *Player, Inventario *InventarioJogador)
{
    system("cls");

    VerificarFome(Player);

    printf("======================================================================================================\n");
    printf("   HP = %i/%i  ||  LEVEL = %i  ||  XP = %i/%i  ||  FOME = %i%%  ||  ENERGIA = %i%%  ||  MOEDAS = %i\n",
           Player->Hp, Player->HpMax, Player->Level, Player->Xp, Player->XpMax,
           Player->Fome, Player->Energia, Player->Moedas);

    printf("======================================================================================================\n");

    printf("\n[SISTEMA] Voce chegou na cidade, porem gastou energia!\n");

    Player->Energia -= 10;

    if(Player->Energia < 0)
    {
        Player->Energia = 0;
    }

    system("pause");

    int opcao;

    if(Player->Energia >= 10)
    {
        do
        {
            system("cls");

            printf("======================================================================================================\n");
            printf("   HP = %i/%i  ||  LEVEL = %i  ||  XP = %i/%i  ||  FOME = %i%%  ||  ENERGIA = %i%%  ||  MOEDAS = %i\n",
                   Player->Hp, Player->HpMax, Player->Level, Player->Xp, Player->XpMax,
                   Player->Fome, Player->Energia, Player->Moedas);

            printf("======================================================================================================\n");
            printf("==================================================\n");
            printf("               BEM-VINDO A CIDADE                 \n");
            printf("==================================================\n");
            printf(" 1 - Descansar na Estalagem (Cura Tudo) [-40 Moedas]\n");
            printf(" 2 - Comer na Taberna (Enche a Fome)    [-20 Moedas]\n");
            printf(" 3 - Visitar o Mercado (Loja de Itens)\n");
            printf(" 4 - Abrir Inventario Pessoal\n");
            printf(" 5 - Sair da Cidade (Voltar ao Menu)\n");
            printf("==================================================\n");

            printf("Escolha uma opcao: ");

            opcao = getch() - '0';

            printf("%i\n", opcao);

            if(opcao < 1 || opcao > 5)
            {
                printf("\nOpcao invalida!\n");
                system("pause");
                continue;
            }

            switch(opcao)
            {
                case 1:
                    // Descansar na estalagem
                    break;

                case 2:
                    // Comer na taberna
                    break;

                case 3:
                    // Loja
                    break;

                case 4:
                    AbrirInventario(Player, InventarioJogador);
                    break;

                case 5:
                    printf("\nSaindo da cidade...\n");
                    break;
            }

        } while(opcao != 5);
    }
    else
    {
        printf("\nVoce esta sem energia para ir ate a cidade! Faca um acampamento para se recuperar!\n");
        system("pause");
    }
}

