#ifndef INVENTARIO_H
#define INVENTARIO_H
#include "Jogador.h"
typedef struct
{
    int Codigo;
    char Nome[50];
    int Preco;
    int Atk;
    int Def;

} Item;


typedef struct
{
    Item *itens; //esse � o ponteiro que aponta para o primeiro indice do nosso vetor dinamico

    int Capacidade;
    int Quantidade;

} Inventario; //controla vetor de itens

void InicializaInventario(Inventario *inv);

int AdicionaItem(Inventario *inv, Item novoItem);

int AumentaInventario(Inventario *inv, int espacos);

void ExibirInventario(Inventario *inv);

Item CriarArmaInicial(unsigned short int ClasseEscolhida);

Item CriarArmaduraInicial(unsigned short int ClasseEscolhida);

void AdicionarEquipamentosIniciais(Jogador *Player, Inventario *InventarioJogador);

#endif

