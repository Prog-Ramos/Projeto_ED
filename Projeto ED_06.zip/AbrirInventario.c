#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#include "Menu.h"

void AbrirInventario(Jogador *Player, Inventario *InventarioJogador)
{
    int i;

    system("cls");

    printf("========================================\n");
    printf("           INVENTARIO PESSOAL           \n");
    printf("========================================\n");

    printf("Espacos ocupados: %i/%i\n\n",
           InventarioJogador->Quantidade,
           InventarioJogador->Capacidade);

    for(i = 0; i < InventarioJogador->Quantidade; i++)
    {
        printf("%i - %s\n", i + 1, InventarioJogador->itens[i].Nome);
    }

    printf("\n========================================\n");
    printf("Pressione qualquer tecla para voltar...\n");

    getch();
}
