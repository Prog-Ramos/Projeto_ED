#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <string.h>
#include "Menu.h"

void Loja(Jogador *Player)
{
    int opcao;
    do {
        system("cls");
        printf("==================================================\n");
        printf("                 LOJA DA CIDADE                   \n");
        printf("==================================================\n");
        printf(" Suas Moedas: %i \n", Player->Moedas);
        printf("--------------------------------------------------\n");
        printf(" 1 - COMPRAR: Pocao de HP   [-15 Moedas]\n");
        printf(" 2 - COMPRAR: Racao         [-8 Moedas]\n");
        printf(" 3 - VENDER:  Pocao de HP   [+7 Moedas]\n");
        printf(" 4 - VENDER:  Racao         [+4 Moedas]\n");
        printf(" 5 - Sair da Loja\n");
        printf("==================================================\n");
        printf("Escolha uma opcao: ");
        scanf("%i", &opcao);


    } while (opcao != 5);
}
